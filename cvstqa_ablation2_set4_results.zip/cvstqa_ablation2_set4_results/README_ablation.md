# Ablation study 2: the final model (M9 with plain concatenation)
Protocol A (random split, seed s = split s, identical to the main study): **10 seeds** ([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]). PLCC/RMSE use the validation-fitted logistic mapping unless stated. Bold = best in a column. Full model = **S1T1M1P1 [FINAL = M9 + plain concatenation]**.

Factors: **S** = spatial attention (alpha); **T** = temporal attention (beta); **M** = multi-stage features (layer2+3); **P** = photometric descriptors. A cell name lists each factor with 1 = present, 0 = removed (S1T1M1P1 is the FINAL model; every cell keeps plain concatenation fusion).

## Factorial cells (all on/off combinations): Overall and Mean(6), mean ± std
| Configuration | Overall SRCC | Overall PLCC | Overall KRCC | Overall RMSE | Mean(6) SRCC | Mean(6) PLCC | Mean(6) KRCC | Mean(6) RMSE |
|---|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | **0.9403 ± 0.0079** | **0.9391 ± 0.0060** | **0.7874 ± 0.0146** | **0.3567 ± 0.0149** | **0.8795 ± 0.0081** | **0.8853 ± 0.0065** | **0.7065 ± 0.0095** | **0.3522 ± 0.0087** |

## Factorial cells (all on/off combinations): Overall and Mean(6), median
| Configuration | Overall SRCC | Overall PLCC | Overall KRCC | Overall RMSE | Mean(6) SRCC | Mean(6) PLCC | Mean(6) KRCC | Mean(6) RMSE |
|---|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | **0.9420** | **0.9400** | **0.7885** | **0.3572** | **0.8776** | **0.8839** | **0.7038** | **0.3542** |

## Manual ablations and controls (one change each, relative to the full model): Overall and Mean(6), mean ± std
| Configuration | Overall SRCC | Overall PLCC | Overall KRCC | Overall RMSE | Mean(6) SRCC | Mean(6) PLCC | Mean(6) KRCC | Mean(6) RMSE |
|---|---|---|---|---|---|---|---|---|
| A4_shared_beta | 0.9395 ± 0.0078 | 0.9392 ± 0.0070 | 0.7865 ± 0.0137 | 0.3562 ± 0.0197 | 0.8779 ± 0.0087 | 0.8842 ± 0.0066 | 0.7049 ± 0.0097 | 0.3530 ± 0.0080 |
| A9_rank0 | 0.9375 ± 0.0072 | 0.9369 ± 0.0063 | 0.7820 ± 0.0139 | 0.3625 ± 0.0168 | 0.8758 ± 0.0045 | 0.8821 ± 0.0042 | 0.7014 ± 0.0043 | 0.3565 ± 0.0061 |
| A9_rank0.05 | 0.9388 ± 0.0079 | 0.9381 ± 0.0058 | 0.7845 ± 0.0129 | 0.3605 ± 0.0126 | 0.8774 ± 0.0086 | 0.8836 ± 0.0069 | 0.7036 ± 0.0097 | 0.3548 ± 0.0093 |
| A9_rank0.2 | 0.9400 ± 0.0078 | 0.9390 ± 0.0056 | **0.7875 ± 0.0130** | 0.3576 ± 0.0140 | 0.8784 ± 0.0097 | 0.8846 ± 0.0074 | 0.7057 ± 0.0110 | 0.3529 ± 0.0091 |
| A9_rank0.5 | 0.9372 ± 0.0095 | 0.9371 ± 0.0078 | 0.7837 ± 0.0156 | 0.3625 ± 0.0222 | **0.8806 ± 0.0102** | **0.8867 ± 0.0084** | **0.7083 ± 0.0116** | **0.3512 ± 0.0091** |
| A9_rank_overall_only | **0.9400 ± 0.0075** | **0.9397 ± 0.0061** | 0.7869 ± 0.0134 | **0.3558 ± 0.0172** | 0.8775 ± 0.0063 | 0.8843 ± 0.0041 | 0.7044 ± 0.0068 | 0.3536 ± 0.0056 |
| X_no_temporal_enc | 0.9390 ± 0.0094 | 0.9382 ± 0.0079 | 0.7858 ± 0.0160 | 0.3593 ± 0.0194 | 0.8801 ± 0.0065 | 0.8857 ± 0.0043 | 0.7071 ± 0.0088 | 0.3527 ± 0.0068 |
| CTRL_ph_shuffled | 0.9325 ± 0.0085 | 0.9339 ± 0.0069 | 0.7753 ± 0.0151 | 0.3718 ± 0.0192 | 0.8694 ± 0.0086 | 0.8774 ± 0.0067 | 0.6955 ± 0.0102 | 0.3617 ± 0.0100 |

## Manual ablations and controls (one change each, relative to the full model): Overall and Mean(6), median
| Configuration | Overall SRCC | Overall PLCC | Overall KRCC | Overall RMSE | Mean(6) SRCC | Mean(6) PLCC | Mean(6) KRCC | Mean(6) RMSE |
|---|---|---|---|---|---|---|---|---|
| A4_shared_beta | 0.9395 | 0.9380 | 0.7854 | 0.3608 | 0.8747 | 0.8832 | 0.7014 | 0.3547 |
| A9_rank0 | 0.9375 | 0.9373 | 0.7795 | 0.3637 | 0.8773 | 0.8826 | 0.7015 | 0.3565 |
| A9_rank0.05 | 0.9365 | 0.9366 | 0.7823 | 0.3605 | 0.8754 | 0.8826 | 0.7009 | 0.3571 |
| A9_rank0.2 | **0.9406** | 0.9390 | **0.7895** | 0.3609 | 0.8760 | 0.8846 | 0.7025 | 0.3548 |
| A9_rank0.5 | 0.9359 | 0.9358 | 0.7813 | 0.3677 | **0.8803** | **0.8870** | **0.7061** | **0.3510** |
| A9_rank_overall_only | 0.9379 | 0.9366 | 0.7848 | 0.3582 | 0.8764 | 0.8852 | 0.7019 | 0.3521 |
| X_no_temporal_enc | 0.9396 | **0.9417** | 0.7887 | **0.3569** | 0.8792 | 0.8849 | 0.7055 | 0.3513 |
| CTRL_ph_shuffled | 0.9311 | 0.9325 | 0.7733 | 0.3724 | 0.8701 | 0.8784 | 0.6948 | 0.3608 |

## Per-score SRCC, all configurations, mean
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.9039 | 0.7829 | 0.8230 | 0.9243 | **0.9024** | **0.9403** | 0.8795 |
| A4_shared_beta | 0.9023 | 0.7811 | 0.8200 | 0.9246 | 0.8996 | 0.9395 | 0.8779 |
| A9_rank0 | 0.9006 | 0.7797 | 0.8184 | 0.9205 | 0.8982 | 0.9375 | 0.8758 |
| A9_rank0.05 | 0.9029 | 0.7802 | 0.8193 | 0.9232 | 0.9001 | 0.9388 | 0.8774 |
| A9_rank0.2 | 0.9035 | 0.7761 | 0.8248 | 0.9245 | 0.9017 | 0.9400 | 0.8784 |
| A9_rank0.5 | **0.9049** | 0.7862 | **0.8291** | 0.9245 | 0.9017 | 0.9372 | **0.8806** |
| A9_rank_overall_only | 0.9000 | 0.7756 | 0.8257 | 0.9235 | 0.9002 | 0.9400 | 0.8775 |
| X_no_temporal_enc | 0.9028 | **0.7879** | 0.8244 | **0.9258** | 0.9008 | 0.9390 | 0.8801 |
| CTRL_ph_shuffled | 0.8982 | 0.7426 | 0.8215 | 0.9205 | 0.9011 | 0.9325 | 0.8694 |

## Per-score SRCC, all configurations, median
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.9036 | 0.7817 | 0.8214 | 0.9277 | 0.8997 | **0.9420** | 0.8776 |
| A4_shared_beta | 0.9042 | 0.7897 | 0.8148 | **0.9301** | 0.8972 | 0.9395 | 0.8747 |
| A9_rank0 | 0.9038 | 0.7797 | 0.8201 | 0.9206 | 0.8977 | 0.9375 | 0.8773 |
| A9_rank0.05 | 0.9037 | 0.7788 | 0.8148 | 0.9250 | 0.8971 | 0.9365 | 0.8754 |
| A9_rank0.2 | 0.9053 | 0.7710 | 0.8229 | 0.9288 | 0.8984 | 0.9406 | 0.8760 |
| A9_rank0.5 | **0.9069** | **0.7962** | **0.8331** | 0.9265 | **0.9019** | 0.9359 | **0.8803** |
| A9_rank_overall_only | 0.8977 | 0.7746 | 0.8243 | 0.9250 | 0.9003 | 0.9379 | 0.8764 |
| X_no_temporal_enc | 0.9034 | 0.7905 | 0.8269 | 0.9279 | 0.8987 | 0.9396 | 0.8792 |
| CTRL_ph_shuffled | 0.8964 | 0.7463 | 0.8246 | 0.9197 | 0.8992 | 0.9311 | 0.8701 |

## Per-score PLCC, all configurations, mean
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.9169 | 0.8014 | 0.8258 | 0.9293 | **0.8995** | 0.9391 | 0.8853 |
| A4_shared_beta | 0.9171 | 0.7979 | 0.8225 | 0.9299 | 0.8985 | 0.9392 | 0.8842 |
| A9_rank0 | 0.9143 | 0.7964 | 0.8222 | 0.9260 | 0.8966 | 0.9369 | 0.8821 |
| A9_rank0.05 | 0.9155 | 0.8011 | 0.8208 | 0.9285 | 0.8974 | 0.9381 | 0.8836 |
| A9_rank0.2 | 0.9168 | 0.7975 | 0.8266 | 0.9295 | 0.8982 | 0.9390 | 0.8846 |
| A9_rank0.5 | **0.9177** | **0.8053** | **0.8310** | 0.9300 | 0.8992 | 0.9371 | **0.8867** |
| A9_rank_overall_only | 0.9150 | 0.7961 | 0.8277 | 0.9293 | 0.8980 | **0.9397** | 0.8843 |
| X_no_temporal_enc | 0.9171 | 0.8038 | 0.8244 | **0.9317** | 0.8988 | 0.9382 | 0.8857 |
| CTRL_ph_shuffled | 0.9135 | 0.7652 | 0.8250 | 0.9277 | 0.8994 | 0.9339 | 0.8774 |

## Per-score PLCC, all configurations, median
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.9196 | 0.8032 | 0.8281 | 0.9285 | 0.8971 | 0.9400 | 0.8839 |
| A4_shared_beta | 0.9205 | 0.7993 | 0.8233 | **0.9332** | 0.8946 | 0.9380 | 0.8832 |
| A9_rank0 | 0.9168 | 0.8006 | 0.8231 | 0.9224 | 0.8983 | 0.9373 | 0.8826 |
| A9_rank0.05 | 0.9177 | 0.8046 | 0.8224 | 0.9287 | 0.8961 | 0.9366 | 0.8826 |
| A9_rank0.2 | 0.9201 | 0.7944 | 0.8282 | 0.9295 | 0.8972 | 0.9390 | 0.8846 |
| A9_rank0.5 | **0.9218** | 0.8026 | **0.8399** | 0.9299 | **0.8996** | 0.9358 | **0.8870** |
| A9_rank_overall_only | 0.9160 | 0.8008 | 0.8263 | 0.9296 | 0.8978 | 0.9366 | 0.8852 |
| X_no_temporal_enc | 0.9169 | **0.8054** | 0.8286 | 0.9305 | 0.8975 | **0.9417** | 0.8849 |
| CTRL_ph_shuffled | 0.9159 | 0.7696 | 0.8277 | 0.9275 | 0.8977 | 0.9325 | 0.8784 |

## Per-score KRCC, all configurations, mean
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.7370 | 0.5928 | 0.6297 | 0.7619 | 0.7300 | 0.7874 | 0.7065 |
| A4_shared_beta | 0.7348 | 0.5907 | 0.6260 | 0.7638 | 0.7278 | 0.7865 | 0.7049 |
| A9_rank0 | 0.7322 | 0.5905 | 0.6239 | 0.7560 | 0.7240 | 0.7820 | 0.7014 |
| A9_rank0.05 | 0.7351 | 0.5902 | 0.6257 | 0.7597 | 0.7266 | 0.7845 | 0.7036 |
| A9_rank0.2 | 0.7359 | 0.5861 | 0.6321 | 0.7627 | 0.7296 | **0.7875** | 0.7057 |
| A9_rank0.5 | **0.7393** | 0.5974 | **0.6370** | 0.7620 | **0.7304** | 0.7837 | **0.7083** |
| A9_rank_overall_only | 0.7321 | 0.5864 | 0.6324 | 0.7610 | 0.7273 | 0.7869 | 0.7044 |
| X_no_temporal_enc | 0.7347 | **0.5979** | 0.6314 | **0.7648** | 0.7283 | 0.7858 | 0.7071 |
| CTRL_ph_shuffled | 0.7294 | 0.5548 | 0.6292 | 0.7562 | 0.7281 | 0.7753 | 0.6955 |

## Per-score KRCC, all configurations, median
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.7344 | 0.5924 | 0.6313 | 0.7678 | 0.7275 | 0.7885 | 0.7038 |
| A4_shared_beta | 0.7348 | 0.5956 | 0.6211 | **0.7715** | 0.7268 | 0.7854 | 0.7014 |
| A9_rank0 | 0.7353 | 0.5913 | 0.6268 | 0.7558 | 0.7241 | 0.7795 | 0.7015 |
| A9_rank0.05 | 0.7340 | 0.5876 | 0.6166 | 0.7605 | 0.7257 | 0.7823 | 0.7009 |
| A9_rank0.2 | 0.7371 | 0.5796 | 0.6270 | 0.7701 | 0.7238 | **0.7895** | 0.7025 |
| A9_rank0.5 | **0.7411** | **0.6029** | **0.6408** | 0.7645 | **0.7306** | 0.7813 | **0.7061** |
| A9_rank_overall_only | 0.7275 | 0.5917 | 0.6289 | 0.7638 | 0.7279 | 0.7848 | 0.7019 |
| X_no_temporal_enc | 0.7360 | 0.6005 | 0.6344 | 0.7691 | 0.7298 | 0.7887 | 0.7055 |
| CTRL_ph_shuffled | 0.7238 | 0.5586 | 0.6325 | 0.7530 | 0.7237 | 0.7733 | 0.6948 |

## Per-score RMSE, all configurations, mean
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.2672 | 0.4905 | 0.3893 | 0.2926 | 0.3171 | 0.3567 | 0.3522 |
| A4_shared_beta | 0.2668 | 0.4932 | 0.3913 | 0.2926 | 0.3181 | 0.3562 | 0.3530 |
| A9_rank0 | 0.2714 | 0.4937 | 0.3917 | **0.2987** | **0.3212** | 0.3625 | 0.3565 |
| A9_rank0.05 | 0.2696 | 0.4893 | **0.3946** | 0.2945 | 0.3205 | 0.3605 | 0.3548 |
| A9_rank0.2 | 0.2670 | 0.4934 | 0.3881 | 0.2925 | 0.3189 | 0.3576 | 0.3529 |
| A9_rank0.5 | 0.2657 | 0.4875 | 0.3835 | 0.2912 | 0.3168 | 0.3625 | 0.3512 |
| A9_rank_overall_only | 0.2695 | 0.4968 | 0.3862 | 0.2933 | 0.3197 | 0.3558 | 0.3536 |
| X_no_temporal_enc | 0.2666 | 0.4937 | 0.3901 | 0.2885 | 0.3181 | 0.3593 | 0.3527 |
| CTRL_ph_shuffled | **0.2716** | **0.5259** | 0.3885 | 0.2955 | 0.3171 | **0.3718** | **0.3617** |

## Per-score RMSE, all configurations, median
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.2641 | 0.4895 | 0.3872 | 0.2921 | 0.3226 | 0.3572 | 0.3542 |
| A4_shared_beta | 0.2631 | 0.4969 | **0.3884** | 0.2891 | 0.3187 | 0.3608 | 0.3547 |
| A9_rank0 | **0.2688** | 0.4894 | 0.3868 | **0.3005** | 0.3220 | 0.3637 | 0.3565 |
| A9_rank0.05 | 0.2655 | 0.4863 | 0.3869 | 0.2968 | **0.3237** | 0.3605 | 0.3571 |
| A9_rank0.2 | 0.2649 | 0.5041 | 0.3861 | 0.2897 | 0.3234 | 0.3609 | 0.3548 |
| A9_rank0.5 | 0.2636 | 0.4954 | 0.3818 | 0.2889 | 0.3209 | 0.3677 | 0.3510 |
| A9_rank_overall_only | 0.2676 | 0.4848 | 0.3867 | 0.2952 | 0.3203 | 0.3582 | 0.3521 |
| X_no_temporal_enc | 0.2637 | 0.4921 | 0.3875 | 0.2888 | 0.3157 | 0.3569 | 0.3513 |
| CTRL_ph_shuffled | 0.2680 | **0.5194** | 0.3838 | 0.2941 | 0.3222 | **0.3724** | **0.3608** |

## Same with the mapping fitted on the test predictions (paper protocol), mean
| Configuration | Overall SRCC | Overall PLCC | Overall KRCC | Overall RMSE | Mean(6) SRCC | Mean(6) PLCC | Mean(6) KRCC | Mean(6) RMSE |
|---|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | **0.9403** | 0.9399 | 0.7874 | 0.3502 | 0.8795 | 0.8886 | 0.7065 | 0.3431 |
| A4_shared_beta | 0.9395 | 0.9398 | 0.7865 | 0.3504 | 0.8779 | 0.8871 | 0.7049 | 0.3448 |
| A9_rank0 | 0.9375 | 0.9375 | 0.7820 | 0.3567 | 0.8758 | 0.8851 | 0.7014 | 0.3485 |
| A9_rank0.05 | 0.9388 | 0.9388 | 0.7845 | 0.3533 | 0.8774 | 0.8867 | 0.7036 | 0.3459 |
| A9_rank0.2 | 0.9400 | 0.9399 | **0.7875** | 0.3503 | 0.8784 | 0.8878 | 0.7057 | 0.3441 |
| A9_rank0.5 | 0.9372 | 0.9380 | 0.7837 | 0.3552 | **0.8806** | **0.8897** | **0.7083** | **0.3423** |
| A9_rank_overall_only | 0.9400 | **0.9404** | 0.7869 | **0.3487** | 0.8775 | 0.8872 | 0.7044 | 0.3451 |
| X_no_temporal_enc | 0.9390 | 0.9391 | 0.7858 | 0.3522 | 0.8801 | 0.8890 | 0.7071 | 0.3428 |
| CTRL_ph_shuffled | 0.9325 | 0.9348 | 0.7753 | 0.3642 | 0.8694 | 0.8806 | 0.6955 | 0.3534 |

## Every configuration vs the full model (paired on the same splits; Holm correction within each metric)
```
              config group                 metric  mean_diff_vs_full  median_diff  seeds_worse_than_full  n  p_wilcoxon  p_holm_within_metric
      A4_shared_beta extra           Overall SRCC            -0.0008      -0.0014                      7 10      0.3750                1.0000
      A4_shared_beta extra           Mean(6) SRCC            -0.0016      -0.0022                      7 10      0.2324                1.0000
      A4_shared_beta extra Overall PLCC (val-fit)             0.0001      -0.0004                      5 10      0.9219                1.0000
      A4_shared_beta extra Overall RMSE (val-fit)            -0.0006       0.0012                      5 10      0.9219                1.0000
            A9_rank0 extra           Overall SRCC            -0.0028      -0.0014                      7 10      0.0645                0.4512
            A9_rank0 extra           Mean(6) SRCC            -0.0037      -0.0020                      7 10      0.1602                1.0000
            A9_rank0 extra Overall PLCC (val-fit)            -0.0021      -0.0005                      6 10      0.2754                1.0000
            A9_rank0 extra Overall RMSE (val-fit)             0.0057       0.0021                      7 10      0.1934                1.0000
         A9_rank0.05 extra           Overall SRCC            -0.0015      -0.0009                      6 10      0.3223                1.0000
         A9_rank0.05 extra           Mean(6) SRCC            -0.0021      -0.0009                      7 10      0.1934                1.0000
         A9_rank0.05 extra Overall PLCC (val-fit)            -0.0010      -0.0002                      6 10      0.4316                1.0000
         A9_rank0.05 extra Overall RMSE (val-fit)             0.0038       0.0010                      7 10      0.1309                0.9160
          A9_rank0.2 extra           Overall SRCC            -0.0004       0.0001                      4 10      0.9219                1.0000
          A9_rank0.2 extra           Mean(6) SRCC            -0.0010      -0.0002                      5 10      0.4922                1.0000
          A9_rank0.2 extra Overall PLCC (val-fit)            -0.0000       0.0006                      2 10      0.1309                0.9160
          A9_rank0.2 extra Overall RMSE (val-fit)             0.0009      -0.0010                      4 10      0.6953                1.0000
          A9_rank0.5 extra           Overall SRCC            -0.0031      -0.0005                      5 10      0.5566                1.0000
          A9_rank0.5 extra           Mean(6) SRCC             0.0011       0.0004                      5 10      0.5566                1.0000
          A9_rank0.5 extra Overall PLCC (val-fit)            -0.0020       0.0002                      5 10      0.7695                1.0000
          A9_rank0.5 extra Overall RMSE (val-fit)             0.0058       0.0006                      6 10      0.5566                1.0000
A9_rank_overall_only extra           Overall SRCC            -0.0003       0.0005                      5 10      0.7695                1.0000
A9_rank_overall_only extra           Mean(6) SRCC            -0.0020      -0.0015                      6 10      0.2754                1.0000
A9_rank_overall_only extra Overall PLCC (val-fit)             0.0006       0.0016                      2 10      0.3223                1.0000
A9_rank_overall_only extra Overall RMSE (val-fit)            -0.0010      -0.0022                      4 10      0.4922                1.0000
   X_no_temporal_enc extra           Overall SRCC            -0.0014      -0.0022                      6 10      0.4922                1.0000
   X_no_temporal_enc extra           Mean(6) SRCC             0.0006       0.0009                      5 10      0.8457                1.0000
   X_no_temporal_enc extra Overall PLCC (val-fit)            -0.0008      -0.0012                      7 10      0.4922                1.0000
   X_no_temporal_enc extra Overall RMSE (val-fit)             0.0026       0.0037                      6 10      0.5566                1.0000
    CTRL_ph_shuffled extra           Overall SRCC            -0.0078      -0.0062                      8 10      0.0098                0.0781
    CTRL_ph_shuffled extra           Mean(6) SRCC            -0.0101      -0.0094                     10 10      0.0020                0.0156
    CTRL_ph_shuffled extra Overall PLCC (val-fit)            -0.0052      -0.0047                      8 10      0.0488                0.3906
    CTRL_ph_shuffled extra Overall RMSE (val-fit)             0.0151       0.0106                      8 10      0.0371                0.2969
```

## Mean SRCC change vs the full model, per score
```
                         TSV       B      SR       S       U  Overall  Mean(6)
A4_shared_beta       -0.0016 -0.0018 -0.0030  0.0003 -0.0027  -0.0008  -0.0016
A9_rank0             -0.0033 -0.0032 -0.0047 -0.0038 -0.0042  -0.0028  -0.0037
A9_rank0.05          -0.0010 -0.0027 -0.0038 -0.0011 -0.0023  -0.0015  -0.0021
A9_rank0.2           -0.0004 -0.0068  0.0018  0.0002 -0.0007  -0.0004  -0.0010
A9_rank0.5            0.0010  0.0033  0.0060  0.0002 -0.0007  -0.0031   0.0011
A9_rank_overall_only -0.0039 -0.0073  0.0027 -0.0008 -0.0022  -0.0003  -0.0020
X_no_temporal_enc    -0.0011  0.0050  0.0014  0.0014 -0.0015  -0.0014   0.0006
CTRL_ph_shuffled     -0.0057 -0.0403 -0.0015 -0.0039 -0.0013  -0.0078  -0.0101
```

## Ranking-loss weight
```
      lambda_r  Overall SRCC  Mean(6) SRCC  Overall RMSE
0 (no ranking)        0.9375        0.8758        0.3625
          0.05        0.9388        0.8774        0.3605
 0.1 (default)        0.9403        0.8795        0.3567
           0.2        0.9400        0.8784        0.3576
           0.5        0.9372        0.8806        0.3625
```

## Attention monitors (collapse check, attribute specificity)
Entropy is normalised to [0,1] (1 = uniform attention, near 0 = collapsed on one patch/frame). beta_attr_diff = mean pairwise half-L1 distance between the five attribute-specific beta curves (0 = identical, 1 = disjoint).
```
                                             spatial_entropy  temporal_entropy  beta_attr_diff
S1T1M1P1 [FINAL = M9 + plain concatenation]           0.9752            0.9927          0.0908
A4_shared_beta                                        0.9791            0.9966          0.0000
A9_rank0                                              0.9691            0.9921          0.0969
A9_rank0.05                                           0.9753            0.9929          0.0905
A9_rank0.2                                            0.9703            0.9935          0.0885
A9_rank0.5                                            0.9816            0.9942          0.0829
A9_rank_overall_only                                  0.9751            0.9934          0.0873
X_no_temporal_enc                                     0.9813            0.9872          0.1153
CTRL_ph_shuffled                                      0.9730            0.9935          0.0884
```

## Frame-order check (full model, test frames shuffled, not retrained)
Overall SRCC 0.9403 -> 0.9400; Mean(6) SRCC 0.8795 -> 0.8792. A small drop means the model uses little temporal order.

## S1T1M1P1 [FINAL = M9 + plain concatenation] vs DARNet (paper protocol)
```
        SRCC DARNet SRCC ours SRCC gap PLCC DARNet PLCC ours PLCC gap KRCC DARNet KRCC ours KRCC gap RMSE DARNet RMSE ours RMSE gap
Score                                                                                                                              
TSV           0.910     0.904   -0.006       0.924     0.920   -0.004       0.744     0.737   -0.007       0.252     0.259   +0.007
B             0.798     0.783   -0.015       0.821     0.808   -0.013       0.607     0.593   -0.014       0.459     0.477   +0.018
SR            0.841     0.823   -0.018       0.855     0.832   -0.023       0.654     0.630   -0.024       0.343     0.376   +0.033
S             0.928     0.924   -0.004       0.933     0.930   -0.003       0.768     0.762   -0.006       0.276     0.288   +0.012
U             0.906     0.902   -0.004       0.914     0.902   -0.012       0.737     0.730   -0.007       0.283     0.308   +0.025
Overall       0.940     0.940   +0.000       0.943     0.940   -0.003       0.790     0.787   -0.003       0.332     0.350   +0.018
Mean(6)       0.887     0.879   -0.008       0.898     0.889   -0.009       0.717     0.706   -0.011       0.324     0.343   +0.019
```

## A9_rank0.5 vs DARNet (paper protocol)
```
        SRCC DARNet SRCC ours SRCC gap PLCC DARNet PLCC ours PLCC gap KRCC DARNet KRCC ours KRCC gap RMSE DARNet RMSE ours RMSE gap
Score                                                                                                                              
TSV           0.910     0.905   -0.005       0.924     0.921   -0.003       0.744     0.739   -0.005       0.252     0.257   +0.005
B             0.798     0.786   -0.012       0.821     0.811   -0.010       0.607     0.597   -0.010       0.459     0.475   +0.016
SR            0.841     0.829   -0.012       0.855     0.837   -0.018       0.654     0.637   -0.017       0.343     0.371   +0.028
S             0.928     0.925   -0.003       0.933     0.931   -0.002       0.768     0.762   -0.006       0.276     0.286   +0.010
U             0.906     0.902   -0.004       0.914     0.901   -0.013       0.737     0.730   -0.007       0.283     0.310   +0.027
Overall       0.940     0.937   -0.003       0.943     0.938   -0.005       0.790     0.784   -0.006       0.332     0.355   +0.023
Mean(6)       0.887     0.881   -0.006       0.898     0.890   -0.008       0.717     0.708   -0.009       0.324     0.342   +0.018
```

Best configuration by mean validation Mean(6) SRCC (selected without test labels): A9_rank0.5 (0.8759). Full model: 0.8753.

## Size and time
```
                                                params  epochs_run  best_epoch  train_s  test_ms_per_clip
S1T1M1P1 [FINAL = M9 + plain concatenation]  4260245.0        19.9         9.9   55.872             1.351
A4_shared_beta                               4194193.0        20.2        10.2   56.464             1.365
A9_rank0                                     4260245.0        23.0        13.8   64.965             1.365
A9_rank0.05                                  4260245.0        20.1        10.1   56.831             1.367
A9_rank0.2                                   4260245.0        21.0        11.0   59.394             1.364
A9_rank0.5                                   4260245.0        16.3         6.3   46.105             1.368
A9_rank_overall_only                         4260245.0        20.2        10.2   57.076             1.367
X_no_temporal_enc                            3201429.0        18.5         8.5   50.576             1.348
CTRL_ph_shuffled                             4260245.0        20.7        10.7   58.302             1.361
```

## Fixed hyper-parameters (identical for every configuration)
```
D                      256.0000
DROPOUT                  0.2000
HEADS                    4.0000
SP_LAYERS                1.0000
T_LAYERS                 2.0000
LR                       0.0005
WD                       0.0100
WARMUP                   2.0000
GRAD_CLIP                1.0000
LAMBDA_RANK              0.1000
RANK_MARGIN              0.0500
LAMBDA_TEMP              0.5000
TEMP_TAU                 0.1000
epochs_max              40.0000
batch                   32.0000
early_stop_patience     10.0000
```

## Logistic-mapping parameters, full model (mean over seeds)
```
                                     config score  val-fit b1  val-fit b2  val-fit b3  val-fit b4  test-fit b1  test-fit b2  test-fit b3  test-fit b4
S1T1M1P1 [FINAL = M9 + plain concatenation]   TSV      88.429    -434.939      -1.652       4.783      126.236      -36.648       18.811        7.818
S1T1M1P1 [FINAL = M9 + plain concatenation]     B       3.416      -0.261       1.540       0.789        3.713       -0.344        1.654        0.675
S1T1M1P1 [FINAL = M9 + plain concatenation]    SR     134.007      -2.118       7.766       2.763       23.908     -118.350        2.800        5.372
S1T1M1P1 [FINAL = M9 + plain concatenation]     S     121.220    -195.672       0.661       4.997      153.696      -33.774        7.212        7.674
S1T1M1P1 [FINAL = M9 + plain concatenation]     U     999.092    -428.005      -8.470      13.417      325.943     -177.297       17.988        8.145
S1T1M1P1 [FINAL = M9 + plain concatenation]     O      62.625    -293.825      -7.741      12.423      117.658      -57.996       13.131        7.382
```
