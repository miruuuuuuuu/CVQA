# Ablation study 2: the final model (M9 with plain concatenation)
Protocol A (random split, seed s = split s, identical to the main study): **10 seeds** ([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]). PLCC/RMSE use the validation-fitted logistic mapping unless stated. Bold = best in a column. Full model = **S1T1M1P1 [FINAL = M9 + plain concatenation]**.

Factors: **S** = spatial attention (alpha); **T** = temporal attention (beta); **M** = multi-stage features (layer2+3); **P** = photometric descriptors. A cell name lists each factor with 1 = present, 0 = removed (S1T1M1P1 is the FINAL model; every cell keeps plain concatenation fusion).

## Factorial cells (all on/off combinations): Overall and Mean(6), mean ± std
| Configuration | Overall SRCC | Overall PLCC | Overall KRCC | Overall RMSE | Mean(6) SRCC | Mean(6) PLCC | Mean(6) KRCC | Mean(6) RMSE |
|---|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | **0.9403 ± 0.0079** | **0.9391 ± 0.0060** | **0.7874 ± 0.0146** | **0.3567 ± 0.0149** | **0.8795 ± 0.0081** | **0.8853 ± 0.0065** | **0.7065 ± 0.0095** | **0.3522 ± 0.0087** |
| S1T1M1P0 | 0.9376 ± 0.0083 | 0.9386 ± 0.0065 | 0.7846 ± 0.0139 | 0.3586 ± 0.0138 | 0.8724 ± 0.0107 | 0.8799 ± 0.0090 | 0.6993 ± 0.0123 | 0.3578 ± 0.0102 |
| S1T1M0P1 | 0.9330 ± 0.0080 | 0.9321 ± 0.0065 | 0.7736 ± 0.0142 | 0.3785 ± 0.0112 | 0.8752 ± 0.0071 | 0.8823 ± 0.0062 | 0.7018 ± 0.0079 | 0.3574 ± 0.0080 |
| S1T0M1P1 | 0.9378 ± 0.0113 | 0.9370 ± 0.0092 | 0.7836 ± 0.0191 | 0.3636 ± 0.0232 | 0.8789 ± 0.0083 | 0.8846 ± 0.0066 | 0.7056 ± 0.0106 | 0.3539 ± 0.0081 |
| S0T1M1P1 | 0.9386 ± 0.0070 | 0.9378 ± 0.0057 | 0.7852 ± 0.0129 | 0.3616 ± 0.0111 | 0.8778 ± 0.0088 | 0.8840 ± 0.0073 | 0.7039 ± 0.0108 | 0.3541 ± 0.0089 |

## Factorial cells (all on/off combinations): Overall and Mean(6), median
| Configuration | Overall SRCC | Overall PLCC | Overall KRCC | Overall RMSE | Mean(6) SRCC | Mean(6) PLCC | Mean(6) KRCC | Mean(6) RMSE |
|---|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | **0.9420** | 0.9400 | **0.7885** | **0.3572** | 0.8776 | **0.8839** | **0.7038** | 0.3542 |
| S1T1M1P0 | 0.9391 | **0.9408** | 0.7878 | 0.3591 | 0.8707 | 0.8810 | 0.6971 | 0.3560 |
| S1T1M0P1 | 0.9326 | 0.9304 | 0.7745 | 0.3818 | 0.8764 | 0.8838 | 0.7030 | 0.3578 |
| S1T0M1P1 | 0.9387 | 0.9379 | 0.7866 | 0.3601 | **0.8791** | 0.8837 | 0.7029 | **0.3529** |
| S0T1M1P1 | 0.9385 | 0.9397 | 0.7855 | 0.3598 | 0.8737 | 0.8827 | 0.6992 | 0.3553 |

## Manual ablations and controls (one change each, relative to the full model): Overall and Mean(6), mean ± std
| Configuration | Overall SRCC | Overall PLCC | Overall KRCC | Overall RMSE | Mean(6) SRCC | Mean(6) PLCC | Mean(6) KRCC | Mean(6) RMSE |
|---|---|---|---|---|---|---|---|---|
| A8_gate_restored | 0.9372 ± 0.0081 | 0.9370 ± 0.0069 | 0.7831 ± 0.0133 | 0.3636 ± 0.0198 | 0.8790 ± 0.0100 | 0.8857 ± 0.0074 | 0.7064 ± 0.0115 | 0.3519 ± 0.0089 |
| A8_cnn_only | 0.9391 ± 0.0089 | **0.9393 ± 0.0075** | **0.7858 ± 0.0156** | **0.3569 ± 0.0185** | 0.8852 ± 0.0071 | **0.8919 ± 0.0047** | 0.7136 ± 0.0082 | **0.3435 ± 0.0059** |
| A8_transformer_only | 0.9368 ± 0.0111 | 0.9366 ± 0.0091 | 0.7818 ± 0.0183 | 0.3637 ± 0.0202 | 0.8762 ± 0.0088 | 0.8831 ± 0.0079 | 0.7029 ± 0.0110 | 0.3547 ± 0.0100 |
| A9_consistency_0.05 | **0.9395 ± 0.0076** | 0.9386 ± 0.0057 | 0.7845 ± 0.0129 | 0.3580 ± 0.0136 | 0.8807 ± 0.0069 | 0.8870 ± 0.0054 | 0.7085 ± 0.0071 | 0.3497 ± 0.0068 |
| A9_consistency_0.5 | 0.9393 ± 0.0089 | 0.9387 ± 0.0071 | 0.7844 ± 0.0145 | 0.3577 ± 0.0202 | **0.8857 ± 0.0072** | 0.8912 ± 0.0042 | **0.7143 ± 0.0076** | 0.3447 ± 0.0048 |

## Manual ablations and controls (one change each, relative to the full model): Overall and Mean(6), median
| Configuration | Overall SRCC | Overall PLCC | Overall KRCC | Overall RMSE | Mean(6) SRCC | Mean(6) PLCC | Mean(6) KRCC | Mean(6) RMSE |
|---|---|---|---|---|---|---|---|---|
| A8_gate_restored | 0.9358 | 0.9363 | 0.7789 | 0.3664 | 0.8749 | 0.8832 | 0.7011 | 0.3530 |
| A8_cnn_only | **0.9415** | **0.9408** | **0.7895** | 0.3596 | 0.8835 | **0.8925** | 0.7122 | **0.3422** |
| A8_transformer_only | 0.9398 | 0.9392 | 0.7847 | 0.3632 | 0.8760 | 0.8847 | 0.7007 | 0.3540 |
| A9_consistency_0.05 | 0.9395 | 0.9389 | 0.7860 | **0.3569** | 0.8786 | 0.8856 | 0.7066 | 0.3513 |
| A9_consistency_0.5 | 0.9404 | 0.9372 | 0.7863 | 0.3596 | **0.8864** | 0.8910 | **0.7144** | 0.3436 |

## Per-score SRCC, all configurations, mean
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.9039 | 0.7829 | 0.8230 | 0.9243 | 0.9024 | **0.9403** | 0.8795 |
| S1T1M1P0 | 0.9001 | 0.7486 | 0.8261 | 0.9230 | 0.8987 | 0.9376 | 0.8724 |
| S1T1M0P1 | 0.9014 | 0.7716 | 0.8188 | 0.9238 | 0.9023 | 0.9330 | 0.8752 |
| S1T0M1P1 | 0.9042 | 0.7839 | 0.8225 | 0.9242 | 0.9007 | 0.9378 | 0.8789 |
| S0T1M1P1 | 0.9022 | 0.7813 | 0.8197 | 0.9228 | 0.9018 | 0.9386 | 0.8778 |
| A8_gate_restored | 0.9020 | 0.7789 | 0.8286 | 0.9242 | 0.9031 | 0.9372 | 0.8790 |
| A8_cnn_only | 0.9077 | 0.7958 | 0.8325 | **0.9294** | 0.9066 | 0.9391 | 0.8852 |
| A8_transformer_only | 0.8992 | 0.7739 | 0.8210 | 0.9254 | 0.9012 | 0.9368 | 0.8762 |
| A9_consistency_0.05 | 0.9067 | 0.7836 | 0.8239 | 0.9265 | 0.9041 | 0.9395 | 0.8807 |
| A9_consistency_0.5 | **0.9092** | **0.7970** | **0.8348** | 0.9257 | **0.9081** | 0.9393 | **0.8857** |

## Per-score SRCC, all configurations, median
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.9036 | 0.7817 | 0.8214 | 0.9277 | 0.8997 | **0.9420** | 0.8776 |
| S1T1M1P0 | 0.8995 | 0.7532 | 0.8265 | 0.9285 | 0.8939 | 0.9391 | 0.8707 |
| S1T1M0P1 | 0.9018 | 0.7738 | 0.8179 | 0.9262 | 0.9017 | 0.9326 | 0.8764 |
| S1T0M1P1 | 0.8996 | 0.7891 | 0.8256 | 0.9258 | 0.8968 | 0.9387 | 0.8791 |
| S0T1M1P1 | 0.9053 | 0.7822 | 0.8255 | 0.9291 | 0.8994 | 0.9385 | 0.8737 |
| A8_gate_restored | 0.9000 | 0.7871 | 0.8323 | 0.9280 | 0.9003 | 0.9358 | 0.8749 |
| A8_cnn_only | 0.9081 | 0.8016 | 0.8347 | **0.9348** | 0.9023 | 0.9415 | 0.8835 |
| A8_transformer_only | 0.9000 | 0.7810 | 0.8256 | 0.9303 | 0.8980 | 0.9398 | 0.8760 |
| A9_consistency_0.05 | **0.9095** | 0.7820 | 0.8149 | 0.9300 | 0.9010 | 0.9395 | 0.8786 |
| A9_consistency_0.5 | 0.9084 | **0.8033** | **0.8369** | 0.9289 | **0.9089** | 0.9404 | **0.8864** |

## Per-score PLCC, all configurations, mean
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.9169 | 0.8014 | 0.8258 | 0.9293 | 0.8995 | 0.9391 | 0.8853 |
| S1T1M1P0 | 0.9154 | 0.7705 | 0.8275 | 0.9291 | 0.8985 | 0.9386 | 0.8799 |
| S1T1M0P1 | 0.9154 | 0.7891 | 0.8253 | 0.9297 | 0.9019 | 0.9321 | 0.8823 |
| S1T0M1P1 | 0.9176 | 0.7994 | 0.8241 | 0.9291 | 0.9006 | 0.9370 | 0.8846 |
| S0T1M1P1 | 0.9172 | 0.8013 | 0.8187 | 0.9294 | 0.8997 | 0.9378 | 0.8840 |
| A8_gate_restored | 0.9165 | 0.7978 | 0.8311 | 0.9305 | 0.9014 | 0.9370 | 0.8857 |
| A8_cnn_only | 0.9209 | **0.8164** | 0.8357 | **0.9342** | 0.9049 | **0.9393** | **0.8919** |
| A8_transformer_only | 0.9140 | 0.7950 | 0.8224 | 0.9309 | 0.9000 | 0.9366 | 0.8831 |
| A9_consistency_0.05 | 0.9188 | 0.8035 | 0.8286 | 0.9310 | 0.9015 | 0.9386 | 0.8870 |
| A9_consistency_0.5 | **0.9217** | 0.8130 | **0.8367** | 0.9308 | **0.9064** | 0.9387 | 0.8912 |

## Per-score PLCC, all configurations, median
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.9196 | 0.8032 | 0.8281 | 0.9285 | 0.8971 | 0.9400 | 0.8839 |
| S1T1M1P0 | 0.9160 | 0.7762 | 0.8258 | 0.9323 | 0.8998 | **0.9408** | 0.8810 |
| S1T1M0P1 | 0.9167 | 0.7892 | 0.8256 | 0.9291 | 0.8981 | 0.9304 | 0.8838 |
| S1T0M1P1 | 0.9203 | 0.7997 | 0.8247 | 0.9286 | 0.8970 | 0.9379 | 0.8837 |
| S0T1M1P1 | 0.9189 | 0.8037 | 0.8240 | 0.9304 | 0.8972 | 0.9397 | 0.8827 |
| A8_gate_restored | 0.9185 | 0.7954 | 0.8351 | 0.9309 | 0.8993 | 0.9363 | 0.8832 |
| A8_cnn_only | 0.9206 | 0.8130 | 0.8389 | **0.9344** | 0.9041 | 0.9408 | **0.8925** |
| A8_transformer_only | 0.9159 | 0.8030 | 0.8298 | 0.9312 | 0.8982 | 0.9392 | 0.8847 |
| A9_consistency_0.05 | 0.9190 | 0.8067 | 0.8257 | 0.9316 | 0.9017 | 0.9389 | 0.8856 |
| A9_consistency_0.5 | **0.9231** | **0.8164** | **0.8393** | 0.9305 | **0.9086** | 0.9372 | 0.8910 |

## Per-score KRCC, all configurations, mean
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.7370 | 0.5928 | 0.6297 | 0.7619 | 0.7300 | **0.7874** | 0.7065 |
| S1T1M1P0 | 0.7325 | 0.5598 | 0.6333 | 0.7598 | 0.7259 | 0.7846 | 0.6993 |
| S1T1M0P1 | 0.7338 | 0.5840 | 0.6286 | 0.7615 | 0.7291 | 0.7736 | 0.7018 |
| S1T0M1P1 | 0.7373 | 0.5934 | 0.6296 | 0.7614 | 0.7285 | 0.7836 | 0.7056 |
| S0T1M1P1 | 0.7343 | 0.5917 | 0.6248 | 0.7594 | 0.7281 | 0.7852 | 0.7039 |
| A8_gate_restored | 0.7346 | 0.5907 | 0.6355 | 0.7631 | 0.7311 | 0.7831 | 0.7064 |
| A8_cnn_only | 0.7429 | 0.6059 | 0.6397 | **0.7710** | 0.7365 | 0.7858 | 0.7136 |
| A8_transformer_only | 0.7307 | 0.5846 | 0.6289 | 0.7630 | 0.7281 | 0.7818 | 0.7029 |
| A9_consistency_0.05 | 0.7411 | 0.5949 | 0.6315 | 0.7662 | 0.7328 | 0.7845 | 0.7085 |
| A9_consistency_0.5 | **0.7456** | **0.6085** | **0.6439** | 0.7657 | **0.7382** | 0.7844 | **0.7143** |

## Per-score KRCC, all configurations, median
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.7344 | 0.5924 | 0.6313 | 0.7678 | 0.7275 | 0.7885 | 0.7038 |
| S1T1M1P0 | 0.7313 | 0.5662 | 0.6351 | 0.7664 | 0.7229 | 0.7878 | 0.6971 |
| S1T1M0P1 | 0.7344 | 0.5878 | 0.6298 | 0.7637 | 0.7280 | 0.7745 | 0.7030 |
| S1T0M1P1 | 0.7337 | 0.5991 | 0.6357 | 0.7652 | 0.7243 | 0.7866 | 0.7029 |
| S0T1M1P1 | 0.7376 | 0.5961 | 0.6301 | 0.7681 | 0.7261 | 0.7855 | 0.6992 |
| A8_gate_restored | 0.7323 | 0.5948 | 0.6385 | 0.7677 | 0.7263 | 0.7789 | 0.7011 |
| A8_cnn_only | 0.7414 | 0.6110 | 0.6405 | **0.7795** | 0.7302 | **0.7895** | 0.7122 |
| A8_transformer_only | 0.7311 | 0.5914 | 0.6300 | 0.7686 | 0.7229 | 0.7847 | 0.7007 |
| A9_consistency_0.05 | 0.7417 | 0.5899 | 0.6231 | 0.7722 | 0.7296 | 0.7860 | 0.7066 |
| A9_consistency_0.5 | **0.7439** | **0.6172** | **0.6442** | 0.7685 | **0.7381** | 0.7863 | **0.7144** |

## Per-score RMSE, all configurations, mean
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.2672 | 0.4905 | 0.3893 | 0.2926 | 0.3171 | 0.3567 | 0.3522 |
| S1T1M1P0 | 0.2692 | **0.5214** | 0.3868 | 0.2926 | **0.3185** | 0.3586 | **0.3578** |
| S1T1M0P1 | 0.2693 | 0.5019 | 0.3887 | 0.2920 | 0.3139 | **0.3785** | 0.3574 |
| S1T0M1P1 | 0.2663 | 0.4946 | 0.3907 | **0.2936** | 0.3144 | 0.3636 | 0.3539 |
| S0T1M1P1 | 0.2671 | 0.4898 | **0.3962** | 0.2932 | 0.3165 | 0.3616 | 0.3541 |
| A8_gate_restored | 0.2671 | 0.4944 | 0.3826 | 0.2902 | 0.3137 | 0.3636 | 0.3519 |
| A8_cnn_only | 0.2605 | 0.4731 | 0.3778 | 0.2837 | 0.3093 | 0.3569 | 0.3435 |
| A8_transformer_only | **0.2710** | 0.4955 | 0.3914 | 0.2905 | 0.3158 | 0.3637 | 0.3547 |
| A9_consistency_0.05 | 0.2643 | 0.4865 | 0.3858 | 0.2895 | 0.3144 | 0.3580 | 0.3497 |
| A9_consistency_0.5 | 0.2597 | 0.4775 | 0.3769 | 0.2903 | 0.3060 | 0.3577 | 0.3447 |

## Per-score RMSE, all configurations, median
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.2641 | 0.4895 | 0.3872 | 0.2921 | **0.3226** | 0.3572 | 0.3542 |
| S1T1M1P0 | 0.2692 | **0.5202** | 0.3821 | 0.2867 | 0.3189 | 0.3591 | 0.3560 |
| S1T1M0P1 | 0.2699 | 0.5082 | 0.3827 | 0.2838 | 0.3154 | **0.3818** | **0.3578** |
| S1T0M1P1 | 0.2640 | 0.4929 | **0.3906** | 0.2922 | 0.3192 | 0.3601 | 0.3529 |
| S0T1M1P1 | 0.2692 | 0.4920 | 0.3879 | **0.2938** | 0.3220 | 0.3598 | 0.3553 |
| A8_gate_restored | 0.2673 | 0.5006 | 0.3794 | 0.2884 | 0.3168 | 0.3664 | 0.3530 |
| A8_cnn_only | 0.2619 | 0.4785 | 0.3747 | 0.2791 | 0.3123 | 0.3596 | 0.3422 |
| A8_transformer_only | **0.2712** | 0.4954 | 0.3837 | 0.2907 | 0.3210 | 0.3632 | 0.3540 |
| A9_consistency_0.05 | 0.2628 | 0.4873 | 0.3813 | 0.2911 | 0.3175 | 0.3569 | 0.3513 |
| A9_consistency_0.5 | 0.2589 | 0.4735 | 0.3779 | 0.2909 | 0.3095 | 0.3596 | 0.3436 |

## Same with the mapping fitted on the test predictions (paper protocol), mean
| Configuration | Overall SRCC | Overall PLCC | Overall KRCC | Overall RMSE | Mean(6) SRCC | Mean(6) PLCC | Mean(6) KRCC | Mean(6) RMSE |
|---|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | **0.9403** | **0.9399** | **0.7874** | **0.3502** | 0.8795 | 0.8886 | 0.7065 | 0.3431 |
| S1T1M1P0 | 0.9376 | 0.9391 | 0.7846 | 0.3523 | 0.8724 | 0.8829 | 0.6993 | 0.3497 |
| S1T1M0P1 | 0.9330 | 0.9330 | 0.7736 | 0.3691 | 0.8752 | 0.8852 | 0.7018 | 0.3489 |
| S1T0M1P1 | 0.9378 | 0.9377 | 0.7836 | 0.3558 | 0.8789 | 0.8884 | 0.7056 | 0.3439 |
| S0T1M1P1 | 0.9386 | 0.9384 | 0.7852 | 0.3541 | 0.8778 | 0.8870 | 0.7039 | 0.3453 |
| A8_gate_restored | 0.9372 | 0.9377 | 0.7831 | 0.3564 | 0.8790 | 0.8886 | 0.7064 | 0.3436 |
| A8_cnn_only | 0.9391 | 0.9397 | 0.7858 | 0.3505 | 0.8852 | **0.8948** | 0.7136 | **0.3351** |
| A8_transformer_only | 0.9368 | 0.9371 | 0.7818 | 0.3573 | 0.8762 | 0.8863 | 0.7029 | 0.3464 |
| A9_consistency_0.05 | 0.9395 | 0.9393 | 0.7845 | 0.3517 | 0.8807 | 0.8902 | 0.7085 | 0.3410 |
| A9_consistency_0.5 | 0.9393 | 0.9395 | 0.7844 | 0.3512 | **0.8857** | 0.8943 | **0.7143** | 0.3361 |

## Every configuration vs the full model (paired on the same splits; Holm correction within each metric)
```
             config     group                 metric  mean_diff_vs_full  median_diff  seeds_worse_than_full  n  p_wilcoxon  p_holm_within_metric
           S1T1M1P0 factorial           Overall SRCC            -0.0027      -0.0038                      8 10      0.1309                0.7852
           S1T1M1P0 factorial           Mean(6) SRCC            -0.0071      -0.0066                      9 10      0.0059                0.0469
           S1T1M1P0 factorial Overall PLCC (val-fit)            -0.0005      -0.0010                      6 10      0.3750                1.0000
           S1T1M1P0 factorial Overall RMSE (val-fit)             0.0018       0.0037                      6 10      0.3750                1.0000
           S1T1M0P1 factorial           Overall SRCC            -0.0074      -0.0082                      9 10      0.0059                0.0527
           S1T1M0P1 factorial           Mean(6) SRCC            -0.0043      -0.0028                      7 10      0.1602                0.6406
           S1T1M0P1 factorial Overall PLCC (val-fit)            -0.0069      -0.0069                      9 10      0.0039                0.0352
           S1T1M0P1 factorial Overall RMSE (val-fit)             0.0217       0.0202                      9 10      0.0039                0.0352
           S1T0M1P1 factorial           Overall SRCC            -0.0025      -0.0028                      8 10      0.1602                0.8008
           S1T0M1P1 factorial           Mean(6) SRCC            -0.0006      -0.0001                      5 10      0.8457                0.8457
           S1T0M1P1 factorial Overall PLCC (val-fit)            -0.0021      -0.0026                      7 10      0.1602                1.0000
           S1T0M1P1 factorial Overall RMSE (val-fit)             0.0068       0.0067                      7 10      0.1055                0.8438
           S0T1M1P1 factorial           Overall SRCC            -0.0017      -0.0023                      8 10      0.1934                0.8008
           S0T1M1P1 factorial           Mean(6) SRCC            -0.0017      -0.0013                      8 10      0.2324                0.6973
           S0T1M1P1 factorial Overall PLCC (val-fit)            -0.0013      -0.0029                      6 10      0.2754                1.0000
           S0T1M1P1 factorial Overall RMSE (val-fit)             0.0049       0.0096                      7 10      0.1934                0.9668
   A8_gate_restored     extra           Overall SRCC            -0.0032      -0.0017                      7 10      0.0840                0.6719
   A8_gate_restored     extra           Mean(6) SRCC            -0.0005      -0.0017                      8 10      0.2324                0.6973
   A8_gate_restored     extra Overall PLCC (val-fit)            -0.0020      -0.0007                      7 10      0.3223                1.0000
   A8_gate_restored     extra Overall RMSE (val-fit)             0.0068       0.0027                      7 10      0.1602                0.9609
        A8_cnn_only     extra           Overall SRCC            -0.0012      -0.0008                      7 10      0.1602                0.8008
        A8_cnn_only     extra           Mean(6) SRCC             0.0057       0.0054                      1 10      0.0039                0.0352
        A8_cnn_only     extra Overall PLCC (val-fit)             0.0003       0.0006                      4 10      0.5566                1.0000
        A8_cnn_only     extra Overall RMSE (val-fit)             0.0001       0.0014                      6 10      0.7695                1.0000
A8_transformer_only     extra           Overall SRCC            -0.0035      -0.0041                      7 10      0.0840                0.6719
A8_transformer_only     extra           Mean(6) SRCC            -0.0032      -0.0032                      7 10      0.1055                0.6328
A8_transformer_only     extra Overall PLCC (val-fit)            -0.0025      -0.0030                      6 10      0.1934                1.0000
A8_transformer_only     extra Overall RMSE (val-fit)             0.0070       0.0085                      7 10      0.1309                0.9160
A9_consistency_0.05     extra           Overall SRCC            -0.0008      -0.0005                      8 10      0.1602                0.8008
A9_consistency_0.05     extra           Mean(6) SRCC             0.0012       0.0022                      4 10      0.1055                0.6328
A9_consistency_0.05     extra Overall PLCC (val-fit)            -0.0005      -0.0001                      6 10      0.4922                1.0000
A9_consistency_0.05     extra Overall RMSE (val-fit)             0.0012       0.0015                      7 10      0.2324                0.9668
 A9_consistency_0.5     extra           Overall SRCC            -0.0010      -0.0020                      7 10      0.4316                0.8008
 A9_consistency_0.5     extra           Mean(6) SRCC             0.0062       0.0068                      2 10      0.0371                0.2598
 A9_consistency_0.5     extra Overall PLCC (val-fit)            -0.0003       0.0003                      3 10      0.8457                1.0000
 A9_consistency_0.5     extra Overall RMSE (val-fit)             0.0010       0.0005                      6 10      0.7695                1.0000
```

## Mean SRCC change vs the full model, per score
```
                        TSV       B      SR       S       U  Overall  Mean(6)
S1T1M1P0            -0.0038 -0.0343  0.0031 -0.0014 -0.0036  -0.0027  -0.0071
S1T1M0P1            -0.0024 -0.0113 -0.0043 -0.0005 -0.0001  -0.0074  -0.0043
S1T0M1P1             0.0003  0.0010 -0.0005 -0.0002 -0.0016  -0.0025  -0.0006
S0T1M1P1            -0.0017 -0.0016 -0.0033 -0.0015 -0.0005  -0.0017  -0.0017
A8_gate_restored    -0.0019 -0.0040  0.0056 -0.0001  0.0007  -0.0032  -0.0005
A8_cnn_only          0.0038  0.0129  0.0095  0.0051  0.0043  -0.0012   0.0057
A8_transformer_only -0.0047 -0.0090 -0.0021  0.0011 -0.0012  -0.0035  -0.0032
A9_consistency_0.05  0.0029  0.0007  0.0009  0.0021  0.0017  -0.0008   0.0012
A9_consistency_0.5   0.0053  0.0141  0.0118  0.0014  0.0057  -0.0010   0.0062
```

## Added temporal-consistency loss
```
lambda_t (added consistency loss)  Overall SRCC  Mean(6) SRCC  Overall RMSE
               none (final model)        0.9403        0.8795        0.3567
                             0.05        0.9395        0.8807        0.3580
                              0.5        0.9393        0.8857        0.3577
```

## Attention monitors (collapse check, attribute specificity)
Entropy is normalised to [0,1] (1 = uniform attention, near 0 = collapsed on one patch/frame). beta_attr_diff = mean pairwise half-L1 distance between the five attribute-specific beta curves (0 = identical, 1 = disjoint).
```
                                             spatial_entropy  temporal_entropy  beta_attr_diff
S1T1M1P1 [FINAL = M9 + plain concatenation]           0.9752            0.9927          0.0908
S1T1M1P0                                              0.9770            0.9949          0.0754
S1T1M0P1                                              0.9807            0.9862          0.1364
S1T0M1P1                                              0.9826               NaN             NaN
S0T1M1P1                                                 NaN            0.9923          0.0917
A8_gate_restored                                      0.8567            0.9939          0.0814
A8_cnn_only                                           0.7574            0.9934          0.0805
A8_transformer_only                                   0.9376            0.9951          0.0753
A9_consistency_0.05                                   0.9612            0.9923          0.0998
A9_consistency_0.5                                    0.9403            0.9804          0.1508
```

## Frame-order check (full model, test frames shuffled, not retrained)
Overall SRCC 0.9403 -> 0.9400; Mean(6) SRCC 0.8795 -> 0.8792. A small drop means the model uses little temporal order.

## Protocol A vs Protocol B (patient-independent split), seeds [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
Check that PATIENT_REGEX really identifies the patient before quoting Protocol B (see Cell 2). Test-set size under B varies by seed (about 207 clips).
```
                                             Overall SRCC A (random)  Mean(6) SRCC A (random)  Overall SRCC B (patient-indep.)  Mean(6) SRCC B (patient-indep.)  Overall drop  Mean(6) drop  Overall RMSE A  Overall RMSE B
config                                                                                                                                                                                                                     
S1T1M1P1 [FINAL = M9 + plain concatenation]                   0.9403                   0.8795                           0.9227                           0.8547        0.0176        0.0248          0.3567          0.4057
```

## S1T1M1P1 [FINAL = M9 + plain concatenation] vs DARNet (paper protocol)
```
        SRCC DARNet SRCC ours SRCC gap PLCC DARNet PLCC ours PLCC gap KRCC DARNet KRCC ours KRCC gap RMSE DARNet RMSE ours RMSE gap
Score                                                                                                                              
TSV           0.910     0.904   -0.006       0.924     0.920   -0.004       0.744     0.737   -0.007       0.252     0.259   +0.007
B             0.798     0.783   -0.015       0.821     0.808   -0.013       0.607     0.593   -0.014       0.459     0.477   +0.018
SR            0.841     0.823   -0.018       0.855     0.832   -0.023       0.654     0.630   -0.024       0.343     0.376   +0.033
S             0.928     0.924   -0.004       0.933     0.930   -0.003       0.768     0.762   -0.006       0.276     0.288   +0.012
U             0.906     0.902   -0.004       0.914     0.902   -0.012       0.737     0.730   -0.007       0.283     0.308   +0.025
Overall       0.940     0.940   +0.000       0.943     0.940   -0.003       0.790     0.787   -0.003       0.332     0.350   +0.018
Mean(6)       0.887     0.879   -0.008       0.898     0.889   -0.009       0.717     0.706   -0.011       0.324     0.343   +0.019
```

## A9_consistency_0.5 vs DARNet (paper protocol)
```
        SRCC DARNet SRCC ours SRCC gap PLCC DARNet PLCC ours PLCC gap KRCC DARNet KRCC ours KRCC gap RMSE DARNet RMSE ours RMSE gap
Score                                                                                                                              
TSV           0.910     0.909   -0.001       0.924     0.925   +0.001       0.744     0.746   +0.002       0.252     0.252   +0.000
B             0.798     0.797   -0.001       0.821     0.820   -0.001       0.607     0.608   +0.001       0.459     0.464   +0.005
SR            0.841     0.835   -0.006       0.855     0.842   -0.013       0.654     0.644   -0.010       0.343     0.365   +0.022
S             0.928     0.926   -0.002       0.933     0.932   -0.001       0.768     0.766   -0.002       0.276     0.285   +0.009
U             0.906     0.908   +0.002       0.914     0.908   -0.006       0.737     0.738   +0.001       0.283     0.299   +0.016
Overall       0.940     0.939   -0.001       0.943     0.939   -0.004       0.790     0.784   -0.006       0.332     0.351   +0.019
Mean(6)       0.887     0.886   -0.001       0.898     0.894   -0.004       0.717     0.714   -0.003       0.324     0.336   +0.012
```

Best configuration by mean validation Mean(6) SRCC (selected without test labels): A9_consistency_0.5 (0.8812). Full model: 0.8753.

## Size and time
```
                                                params  epochs_run  best_epoch  train_s  test_ms_per_clip
S1T1M1P1 [FINAL = M9 + plain concatenation]  4260245.0        19.9         9.9   56.328             1.343
S1T1M1P0                                     4115861.0        19.7         9.7   55.100             1.339
S1T1M0P1                                     3473813.0        17.0         7.0   40.460             1.026
S1T0M1P1                                     4177680.0        18.7         8.7   51.882             1.341
S0T1M1P1                                     4095120.0        17.6         7.6   43.403             1.226
A8_gate_restored                             4259733.0        17.6         7.6   50.364             1.370
A8_cnn_only                                  4128405.0        17.7         7.7   34.524             1.250
A8_transformer_only                          4128405.0        18.9         9.4   49.186             1.250
A9_consistency_0.05                          4260245.0        23.4        13.5   66.032             1.345
A9_consistency_0.5                           4260245.0        23.9        13.9   67.732             1.341
```

## Fixed hyper-parameters (identical for every configuration)
```
D                      256.0000
DROPOUT                  0.2000
HEADS                    4.0000
SP_LAYERS                1.0000
T_LAYERS                 2.0000
LR                       0.0005
WD                       0.0100
WARMUP                   2.0000
GRAD_CLIP                1.0000
LAMBDA_RANK              0.1000
RANK_MARGIN              0.0500
LAMBDA_TEMP              0.5000
TEMP_TAU                 0.1000
epochs_max              40.0000
batch                   32.0000
early_stop_patience     10.0000
```

## Logistic-mapping parameters, full model (mean over seeds)
```
                                     config score  val-fit b1  val-fit b2  val-fit b3  val-fit b4  test-fit b1  test-fit b2  test-fit b3  test-fit b4
S1T1M1P1 [FINAL = M9 + plain concatenation]   TSV      88.429    -434.939      -1.652       4.783      126.236      -36.648       18.811        7.818
S1T1M1P1 [FINAL = M9 + plain concatenation]     B       3.416      -0.261       1.540       0.789        3.713       -0.344        1.654        0.675
S1T1M1P1 [FINAL = M9 + plain concatenation]    SR     134.007      -2.118       7.766       2.763       23.908     -118.350        2.800        5.372
S1T1M1P1 [FINAL = M9 + plain concatenation]     S     121.220    -195.672       0.661       4.997      153.696      -33.774        7.212        7.674
S1T1M1P1 [FINAL = M9 + plain concatenation]     U     999.092    -428.005      -8.470      13.417      325.943     -177.297       17.988        8.145
S1T1M1P1 [FINAL = M9 + plain concatenation]     O      62.625    -293.825      -7.741      12.423      117.658      -57.996       13.131        7.382
```
