# Ablation study 2: the final model (M9 with plain concatenation)
Protocol A (random split, seed s = split s, identical to the main study): **10 seeds** ([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]). PLCC/RMSE use the validation-fitted logistic mapping unless stated. Bold = best in a column. Full model = **S1T1M1P1 [FINAL = M9 + plain concatenation]**.

Factors: **S** = spatial attention (alpha); **T** = temporal attention (beta); **M** = multi-stage features (layer2+3); **P** = photometric descriptors. A cell name lists each factor with 1 = present, 0 = removed (S1T1M1P1 is the FINAL model; every cell keeps plain concatenation fusion).

## Factorial cells (all on/off combinations): Overall and Mean(6), mean ± std
| Configuration | Overall SRCC | Overall PLCC | Overall KRCC | Overall RMSE | Mean(6) SRCC | Mean(6) PLCC | Mean(6) KRCC | Mean(6) RMSE |
|---|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | **0.9403 ± 0.0079** | **0.9391 ± 0.0060** | **0.7874 ± 0.0146** | **0.3567 ± 0.0149** | **0.8795 ± 0.0081** | **0.8853 ± 0.0065** | **0.7065 ± 0.0095** | **0.3522 ± 0.0087** |
| S1T0M0P0 | 0.9267 ± 0.0072 | 0.9270 ± 0.0061 | 0.7647 ± 0.0114 | 0.3903 ± 0.0085 | 0.8706 ± 0.0063 | 0.8773 ± 0.0057 | 0.6962 ± 0.0069 | 0.3644 ± 0.0078 |
| S0T1M0P0 | 0.9304 ± 0.0083 | 0.9302 ± 0.0071 | 0.7701 ± 0.0142 | 0.3818 ± 0.0163 | 0.8724 ± 0.0108 | 0.8788 ± 0.0080 | 0.6986 ± 0.0121 | 0.3613 ± 0.0110 |
| S0T0M1P0 | 0.9383 ± 0.0086 | 0.9388 ± 0.0076 | 0.7844 ± 0.0156 | 0.3574 ± 0.0176 | 0.8727 ± 0.0103 | 0.8798 ± 0.0082 | 0.6993 ± 0.0121 | 0.3590 ± 0.0110 |
| S0T0M0P1 | 0.9340 ± 0.0077 | 0.9331 ± 0.0079 | 0.7749 ± 0.0149 | 0.3737 ± 0.0180 | 0.8777 ± 0.0059 | 0.8838 ± 0.0051 | 0.7043 ± 0.0066 | 0.3552 ± 0.0059 |
| S0T0M0P0 | 0.9300 ± 0.0080 | 0.9301 ± 0.0072 | 0.7701 ± 0.0139 | 0.3822 ± 0.0140 | 0.8717 ± 0.0089 | 0.8779 ± 0.0077 | 0.6978 ± 0.0101 | 0.3628 ± 0.0071 |

## Factorial cells (all on/off combinations): Overall and Mean(6), median
| Configuration | Overall SRCC | Overall PLCC | Overall KRCC | Overall RMSE | Mean(6) SRCC | Mean(6) PLCC | Mean(6) KRCC | Mean(6) RMSE |
|---|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | **0.9420** | 0.9400 | **0.7885** | **0.3572** | 0.8776 | **0.8839** | 0.7038 | **0.3542** |
| S1T0M0P0 | 0.9264 | 0.9263 | 0.7652 | 0.3888 | 0.8708 | 0.8787 | 0.6963 | 0.3642 |
| S0T1M0P0 | 0.9313 | 0.9300 | 0.7701 | 0.3847 | 0.8719 | 0.8789 | 0.6982 | 0.3620 |
| S0T0M1P0 | 0.9390 | **0.9405** | 0.7859 | 0.3616 | 0.8725 | 0.8779 | 0.6982 | 0.3601 |
| S0T0M0P1 | 0.9338 | 0.9322 | 0.7729 | 0.3734 | **0.8789** | 0.8836 | **0.7066** | 0.3565 |
| S0T0M0P0 | 0.9325 | 0.9312 | 0.7736 | 0.3863 | 0.8717 | 0.8801 | 0.6985 | 0.3622 |

## Manual ablations and controls (one change each, relative to the full model): Overall and Mean(6), mean ± std
| Configuration | Overall SRCC | Overall PLCC | Overall KRCC | Overall RMSE | Mean(6) SRCC | Mean(6) PLCC | Mean(6) KRCC | Mean(6) RMSE |
|---|---|---|---|---|---|---|---|---|
| A5_T8 | 0.9206 ± 0.0067 | 0.9215 ± 0.0055 | 0.7529 ± 0.0119 | 0.4074 ± 0.0117 | 0.8539 ± 0.0115 | 0.8607 ± 0.0109 | 0.6725 ± 0.0133 | 0.3880 ± 0.0114 |
| A6_grid4 | 0.9399 ± 0.0088 | 0.9392 ± 0.0070 | 0.7868 ± 0.0156 | 0.3572 ± 0.0188 | 0.8827 ± 0.0058 | 0.8889 ± 0.0040 | 0.7111 ± 0.0065 | 0.3472 ± 0.0044 |
| A6_grid3 | 0.9387 ± 0.0078 | 0.9382 ± 0.0066 | 0.7847 ± 0.0142 | 0.3608 ± 0.0174 | 0.8853 ± 0.0071 | 0.8912 ± 0.0054 | 0.7135 ± 0.0083 | 0.3449 ± 0.0047 |
| A6_grid2 | **0.9413 ± 0.0082** | **0.9406 ± 0.0071** | **0.7884 ± 0.0155** | **0.3533 ± 0.0168** | **0.8855 ± 0.0090** | **0.8920 ± 0.0057** | **0.7145 ± 0.0099** | **0.3428 ± 0.0060** |

## Manual ablations and controls (one change each, relative to the full model): Overall and Mean(6), median
| Configuration | Overall SRCC | Overall PLCC | Overall KRCC | Overall RMSE | Mean(6) SRCC | Mean(6) PLCC | Mean(6) KRCC | Mean(6) RMSE |
|---|---|---|---|---|---|---|---|---|
| A5_T8 | 0.9223 | 0.9221 | 0.7552 | 0.4022 | 0.8558 | 0.8631 | 0.6744 | 0.3862 |
| A6_grid4 | **0.9404** | 0.9389 | 0.7873 | 0.3582 | 0.8817 | 0.8902 | 0.7109 | 0.3478 |
| A6_grid3 | 0.9356 | 0.9378 | 0.7797 | 0.3638 | 0.8841 | 0.8917 | **0.7142** | 0.3455 |
| A6_grid2 | 0.9401 | **0.9426** | **0.7876** | **0.3531** | **0.8848** | **0.8927** | 0.7131 | **0.3432** |

## Per-score SRCC, all configurations, mean
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.9039 | 0.7829 | 0.8230 | 0.9243 | 0.9024 | 0.9403 | 0.8795 |
| S1T0M0P0 | 0.8973 | 0.7603 | 0.8194 | 0.9207 | 0.8995 | 0.9267 | 0.8706 |
| S0T1M0P0 | 0.9008 | 0.7546 | 0.8188 | 0.9253 | 0.9046 | 0.9304 | 0.8724 |
| S0T0M1P0 | 0.8993 | 0.7574 | 0.8190 | 0.9217 | 0.9004 | 0.9383 | 0.8727 |
| S0T0M0P1 | 0.9037 | 0.7763 | 0.8272 | 0.9254 | 0.8995 | 0.9340 | 0.8777 |
| S0T0M0P0 | 0.9001 | 0.7545 | 0.8190 | 0.9228 | 0.9036 | 0.9300 | 0.8717 |
| A5_T8 | 0.8837 | 0.7414 | 0.7981 | 0.9015 | 0.8780 | 0.9206 | 0.8539 |
| A6_grid4 | 0.9063 | 0.7868 | 0.8340 | 0.9257 | 0.9035 | 0.9399 | 0.8827 |
| A6_grid3 | 0.9065 | **0.7934** | 0.8361 | 0.9282 | **0.9087** | 0.9387 | 0.8853 |
| A6_grid2 | **0.9075** | 0.7914 | **0.8372** | **0.9290** | 0.9067 | **0.9413** | **0.8855** |

## Per-score SRCC, all configurations, median
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.9036 | 0.7817 | 0.8214 | 0.9277 | 0.8997 | **0.9420** | 0.8776 |
| S1T0M0P0 | 0.8996 | 0.7569 | 0.8231 | 0.9256 | 0.8976 | 0.9264 | 0.8708 |
| S0T1M0P0 | 0.9008 | 0.7611 | 0.8248 | 0.9306 | 0.9043 | 0.9313 | 0.8719 |
| S0T0M1P0 | 0.8998 | 0.7548 | 0.8187 | 0.9270 | 0.8971 | 0.9390 | 0.8725 |
| S0T0M0P1 | 0.9055 | 0.7734 | 0.8303 | 0.9258 | 0.8998 | 0.9338 | 0.8789 |
| S0T0M0P0 | 0.8982 | 0.7574 | 0.8219 | 0.9249 | 0.9051 | 0.9325 | 0.8717 |
| A5_T8 | 0.8848 | 0.7410 | 0.8054 | 0.9069 | 0.8764 | 0.9223 | 0.8558 |
| A6_grid4 | 0.9045 | 0.7898 | 0.8360 | 0.9297 | 0.9019 | 0.9404 | 0.8817 |
| A6_grid3 | **0.9067** | **0.7943** | 0.8368 | 0.9298 | **0.9075** | 0.9356 | 0.8841 |
| A6_grid2 | 0.9031 | 0.7934 | **0.8375** | **0.9323** | 0.9074 | 0.9401 | **0.8848** |

## Per-score PLCC, all configurations, mean
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.9169 | 0.8014 | 0.8258 | 0.9293 | 0.8995 | 0.9391 | 0.8853 |
| S1T0M0P0 | 0.9132 | 0.7736 | 0.8242 | 0.9277 | 0.8983 | 0.9270 | 0.8773 |
| S0T1M0P0 | 0.9134 | 0.7736 | 0.8230 | 0.9307 | 0.9022 | 0.9302 | 0.8788 |
| S0T0M1P0 | 0.9141 | 0.7777 | 0.8227 | 0.9265 | 0.8987 | 0.9388 | 0.8798 |
| S0T0M0P1 | 0.9162 | 0.7957 | 0.8287 | 0.9304 | 0.8989 | 0.9331 | 0.8838 |
| S0T0M0P0 | 0.9145 | 0.7715 | 0.8231 | 0.9276 | 0.9004 | 0.9301 | 0.8779 |
| A5_T8 | 0.9005 | 0.7621 | 0.7960 | 0.9087 | 0.8757 | 0.9215 | 0.8607 |
| A6_grid4 | 0.9204 | 0.8037 | 0.8355 | 0.9315 | 0.9033 | 0.9392 | 0.8889 |
| A6_grid3 | 0.9206 | **0.8099** | 0.8385 | 0.9326 | **0.9074** | 0.9382 | 0.8912 |
| A6_grid2 | **0.9206** | 0.8093 | **0.8418** | **0.9336** | 0.9060 | **0.9406** | **0.8920** |

## Per-score PLCC, all configurations, median
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.9196 | 0.8032 | 0.8281 | 0.9285 | 0.8971 | 0.9400 | 0.8839 |
| S1T0M0P0 | 0.9161 | 0.7731 | 0.8307 | 0.9279 | 0.8991 | 0.9263 | 0.8787 |
| S0T1M0P0 | 0.9164 | 0.7785 | 0.8328 | 0.9316 | 0.9017 | 0.9300 | 0.8789 |
| S0T0M1P0 | 0.9163 | 0.7766 | 0.8221 | 0.9292 | 0.8967 | 0.9405 | 0.8779 |
| S0T0M0P1 | 0.9158 | 0.7945 | 0.8312 | 0.9290 | 0.8977 | 0.9322 | 0.8836 |
| S0T0M0P0 | 0.9157 | 0.7764 | 0.8272 | 0.9282 | 0.8998 | 0.9312 | 0.8801 |
| A5_T8 | 0.9017 | 0.7652 | 0.8049 | 0.9066 | 0.8745 | 0.9221 | 0.8631 |
| A6_grid4 | **0.9225** | 0.8022 | 0.8407 | **0.9357** | 0.9039 | 0.9389 | 0.8902 |
| A6_grid3 | 0.9219 | 0.8105 | 0.8403 | 0.9333 | **0.9094** | 0.9378 | 0.8917 |
| A6_grid2 | 0.9198 | **0.8109** | **0.8434** | 0.9333 | 0.9055 | **0.9426** | **0.8927** |

## Per-score KRCC, all configurations, mean
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.7370 | 0.5928 | 0.6297 | 0.7619 | 0.7300 | 0.7874 | 0.7065 |
| S1T0M0P0 | 0.7289 | 0.5733 | 0.6282 | 0.7574 | 0.7246 | 0.7647 | 0.6962 |
| S0T1M0P0 | 0.7318 | 0.5690 | 0.6271 | 0.7621 | 0.7316 | 0.7701 | 0.6986 |
| S0T0M1P0 | 0.7310 | 0.5691 | 0.6259 | 0.7577 | 0.7279 | 0.7844 | 0.6993 |
| S0T0M0P1 | 0.7369 | 0.5883 | 0.6371 | 0.7624 | 0.7260 | 0.7749 | 0.7043 |
| S0T0M0P0 | 0.7314 | 0.5674 | 0.6275 | 0.7591 | 0.7313 | 0.7701 | 0.6978 |
| A5_T8 | 0.7077 | 0.5528 | 0.6025 | 0.7255 | 0.6938 | 0.7529 | 0.6725 |
| A6_grid4 | 0.7421 | 0.5975 | 0.6426 | 0.7653 | 0.7324 | 0.7868 | 0.7111 |
| A6_grid3 | 0.7422 | **0.6043** | 0.6439 | 0.7670 | **0.7386** | 0.7847 | 0.7135 |
| A6_grid2 | **0.7431** | 0.6039 | **0.6455** | **0.7697** | 0.7366 | **0.7884** | **0.7145** |

## Per-score KRCC, all configurations, median
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.7344 | 0.5924 | 0.6313 | 0.7678 | 0.7275 | **0.7885** | 0.7038 |
| S1T0M0P0 | 0.7305 | 0.5686 | 0.6314 | 0.7660 | 0.7225 | 0.7652 | 0.6963 |
| S0T1M0P0 | 0.7314 | 0.5735 | 0.6340 | 0.7700 | 0.7312 | 0.7701 | 0.6982 |
| S0T0M1P0 | 0.7325 | 0.5700 | 0.6257 | 0.7656 | 0.7231 | 0.7859 | 0.6982 |
| S0T0M0P1 | 0.7365 | 0.5877 | 0.6405 | 0.7620 | 0.7264 | 0.7729 | 0.7066 |
| S0T0M0P0 | 0.7298 | 0.5705 | 0.6309 | 0.7644 | 0.7315 | 0.7736 | 0.6985 |
| A5_T8 | 0.7066 | 0.5528 | 0.6062 | 0.7348 | 0.6901 | 0.7552 | 0.6744 |
| A6_grid4 | 0.7389 | 0.6043 | **0.6466** | 0.7714 | 0.7314 | 0.7873 | 0.7109 |
| A6_grid3 | **0.7398** | **0.6061** | 0.6432 | 0.7677 | 0.7360 | 0.7797 | **0.7142** |
| A6_grid2 | 0.7358 | 0.6047 | 0.6425 | **0.7752** | **0.7369** | 0.7876 | 0.7131 |

## Per-score RMSE, all configurations, mean
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.2672 | 0.4905 | 0.3893 | 0.2926 | 0.3171 | 0.3567 | 0.3522 |
| S1T0M0P0 | 0.2727 | 0.5186 | 0.3893 | 0.2962 | 0.3190 | 0.3903 | 0.3644 |
| S0T1M0P0 | 0.2719 | 0.5197 | 0.3905 | 0.2907 | 0.3129 | 0.3818 | 0.3613 |
| S0T0M1P0 | 0.2714 | 0.5159 | 0.3940 | 0.2978 | 0.3176 | 0.3574 | 0.3590 |
| S0T0M0P1 | 0.2685 | 0.4959 | 0.3839 | 0.2914 | 0.3176 | 0.3737 | 0.3552 |
| S0T0M0P0 | 0.2714 | 0.5209 | 0.3909 | 0.2970 | 0.3143 | 0.3822 | 0.3628 |
| A5_T8 | **0.2921** | **0.5304** | **0.4147** | **0.3318** | **0.3516** | **0.4074** | **0.3880** |
| A6_grid4 | 0.2612 | 0.4868 | 0.3790 | 0.2884 | 0.3107 | 0.3572 | 0.3472 |
| A6_grid3 | 0.2610 | 0.4808 | 0.3753 | 0.2872 | 0.3041 | 0.3608 | 0.3449 |
| A6_grid2 | 0.2612 | 0.4801 | 0.3712 | 0.2851 | 0.3058 | 0.3533 | 0.3428 |

## Per-score RMSE, all configurations, median
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.2641 | 0.4895 | 0.3872 | 0.2921 | 0.3226 | 0.3572 | 0.3542 |
| S1T0M0P0 | 0.2741 | 0.5173 | 0.3860 | 0.2915 | 0.3225 | 0.3888 | 0.3642 |
| S0T1M0P0 | 0.2748 | **0.5199** | 0.3884 | 0.2815 | 0.3184 | 0.3847 | 0.3620 |
| S0T0M1P0 | 0.2693 | 0.5147 | 0.3866 | 0.2963 | 0.3190 | 0.3616 | 0.3601 |
| S0T0M0P1 | 0.2710 | 0.4953 | 0.3823 | 0.2848 | 0.3188 | 0.3734 | 0.3565 |
| S0T0M0P0 | 0.2771 | 0.5154 | 0.3956 | 0.2895 | 0.3174 | 0.3863 | 0.3622 |
| A5_T8 | **0.2918** | 0.5145 | **0.4143** | **0.3323** | **0.3551** | **0.4022** | **0.3862** |
| A6_grid4 | 0.2630 | 0.4892 | 0.3750 | 0.2785 | 0.3137 | 0.3582 | 0.3478 |
| A6_grid3 | 0.2596 | 0.4733 | 0.3693 | 0.2916 | 0.3049 | 0.3638 | 0.3455 |
| A6_grid2 | 0.2662 | 0.4831 | 0.3728 | 0.2797 | 0.3106 | 0.3531 | 0.3432 |

## Same with the mapping fitted on the test predictions (paper protocol), mean
| Configuration | Overall SRCC | Overall PLCC | Overall KRCC | Overall RMSE | Mean(6) SRCC | Mean(6) PLCC | Mean(6) KRCC | Mean(6) RMSE |
|---|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.9403 | 0.9399 | 0.7874 | 0.3502 | 0.8795 | 0.8886 | 0.7065 | 0.3431 |
| S1T0M0P0 | 0.9267 | 0.9283 | 0.7647 | 0.3813 | 0.8706 | 0.8810 | 0.6962 | 0.3552 |
| S0T1M0P0 | 0.9304 | 0.9313 | 0.7701 | 0.3732 | 0.8724 | 0.8821 | 0.6986 | 0.3522 |
| S0T0M1P0 | 0.9383 | 0.9396 | 0.7844 | 0.3507 | 0.8727 | 0.8825 | 0.6993 | 0.3503 |
| S0T0M0P1 | 0.9340 | 0.9340 | 0.7749 | 0.3660 | 0.8777 | 0.8874 | 0.7043 | 0.3462 |
| S0T0M0P0 | 0.9300 | 0.9314 | 0.7701 | 0.3732 | 0.8717 | 0.8811 | 0.6978 | 0.3538 |
| A5_T8 | 0.9206 | 0.9222 | 0.7529 | 0.3966 | 0.8539 | 0.8643 | 0.6725 | 0.3779 |
| A6_grid4 | 0.9399 | 0.9396 | 0.7868 | 0.3508 | 0.8827 | 0.8914 | 0.7111 | 0.3395 |
| A6_grid3 | 0.9387 | 0.9388 | 0.7847 | 0.3530 | 0.8853 | 0.8940 | 0.7135 | 0.3363 |
| A6_grid2 | **0.9413** | **0.9411** | **0.7884** | **0.3463** | **0.8855** | **0.8947** | **0.7145** | **0.3349** |

## Every configuration vs the full model (paired on the same splits; Holm correction within each metric)
```
  config     group                 metric  mean_diff_vs_full  median_diff  seeds_worse_than_full  n  p_wilcoxon  p_holm_within_metric
S1T0M0P0 factorial           Overall SRCC            -0.0136      -0.0135                     10 10      0.0020                0.0176
S1T0M0P0 factorial           Mean(6) SRCC            -0.0088      -0.0061                     10 10      0.0020                0.0176
S1T0M0P0 factorial Overall PLCC (val-fit)            -0.0121      -0.0113                     10 10      0.0020                0.0176
S1T0M0P0 factorial Overall RMSE (val-fit)             0.0336       0.0350                     10 10      0.0020                0.0176
S0T1M0P0 factorial           Overall SRCC            -0.0100      -0.0098                      9 10      0.0039                0.0195
S0T1M0P0 factorial           Mean(6) SRCC            -0.0071      -0.0071                      9 10      0.0273                0.1094
S0T1M0P0 factorial Overall PLCC (val-fit)            -0.0089      -0.0085                     10 10      0.0020                0.0176
S0T1M0P0 factorial Overall RMSE (val-fit)             0.0251       0.0235                     10 10      0.0020                0.0176
S0T0M1P0 factorial           Overall SRCC            -0.0020      -0.0027                      6 10      0.2754                1.0000
S0T0M1P0 factorial           Mean(6) SRCC            -0.0068      -0.0055                     10 10      0.0020                0.0176
S0T0M1P0 factorial Overall PLCC (val-fit)            -0.0002      -0.0001                      5 10      1.0000                1.0000
S0T0M1P0 factorial Overall RMSE (val-fit)             0.0007       0.0010                      5 10      0.9219                1.0000
S0T0M0P1 factorial           Overall SRCC            -0.0063      -0.0058                     10 10      0.0020                0.0176
S0T0M0P1 factorial           Mean(6) SRCC            -0.0018      -0.0006                      6 10      0.6250                0.6250
S0T0M0P1 factorial Overall PLCC (val-fit)            -0.0059      -0.0064                     10 10      0.0020                0.0176
S0T0M0P1 factorial Overall RMSE (val-fit)             0.0170       0.0165                     10 10      0.0020                0.0176
S0T0M0P0 factorial           Overall SRCC            -0.0103      -0.0100                     10 10      0.0020                0.0176
S0T0M0P0 factorial           Mean(6) SRCC            -0.0078      -0.0080                      9 10      0.0059                0.0293
S0T0M0P0 factorial Overall PLCC (val-fit)            -0.0090      -0.0081                     10 10      0.0020                0.0176
S0T0M0P0 factorial Overall RMSE (val-fit)             0.0254       0.0238                     10 10      0.0020                0.0176
   A5_T8     extra           Overall SRCC            -0.0197      -0.0212                     10 10      0.0020                0.0176
   A5_T8     extra           Mean(6) SRCC            -0.0256      -0.0231                     10 10      0.0020                0.0176
   A5_T8     extra Overall PLCC (val-fit)            -0.0176      -0.0187                     10 10      0.0020                0.0176
   A5_T8     extra Overall RMSE (val-fit)             0.0506       0.0488                     10 10      0.0020                0.0176
A6_grid4     extra           Overall SRCC            -0.0004      -0.0007                      5 10      0.6953                1.0000
A6_grid4     extra           Mean(6) SRCC             0.0032       0.0034                      2 10      0.0840                0.2520
A6_grid4     extra Overall PLCC (val-fit)             0.0001      -0.0006                      5 10      1.0000                1.0000
A6_grid4     extra Overall RMSE (val-fit)             0.0005       0.0026                      5 10      1.0000                1.0000
A6_grid3     extra           Overall SRCC            -0.0016      -0.0009                      7 10      0.2754                1.0000
A6_grid3     extra           Mean(6) SRCC             0.0058       0.0061                      1 10      0.0039                0.0234
A6_grid3     extra Overall PLCC (val-fit)            -0.0009      -0.0007                      6 10      0.4922                1.0000
A6_grid3     extra Overall RMSE (val-fit)             0.0041       0.0055                      7 10      0.3750                1.0000
A6_grid2     extra           Overall SRCC             0.0009      -0.0012                      7 10      0.9219                1.0000
A6_grid2     extra           Mean(6) SRCC             0.0060       0.0041                      4 10      0.1309                0.2617
A6_grid2     extra Overall PLCC (val-fit)             0.0015      -0.0003                      6 10      0.6953                1.0000
A6_grid2     extra Overall RMSE (val-fit)            -0.0034       0.0028                      6 10      0.8457                1.0000
```

## Mean SRCC change vs the full model, per score
```
             TSV       B      SR       S       U  Overall  Mean(6)
S1T0M0P0 -0.0066 -0.0226 -0.0036 -0.0037 -0.0029  -0.0136  -0.0088
S0T1M0P0 -0.0031 -0.0283 -0.0042  0.0010  0.0022  -0.0100  -0.0071
S0T0M1P0 -0.0046 -0.0255 -0.0040 -0.0027 -0.0020  -0.0020  -0.0068
S0T0M0P1 -0.0002 -0.0066  0.0042  0.0011 -0.0029  -0.0063  -0.0018
S0T0M0P0 -0.0038 -0.0284 -0.0040 -0.0015  0.0012  -0.0103  -0.0078
A5_T8    -0.0202 -0.0415 -0.0250 -0.0228 -0.0243  -0.0197  -0.0256
A6_grid4  0.0024  0.0039  0.0109  0.0013  0.0011  -0.0004   0.0032
A6_grid3  0.0026  0.0105  0.0131  0.0039  0.0063  -0.0016   0.0058
A6_grid2  0.0036  0.0085  0.0142  0.0046  0.0043   0.0009   0.0060
```

## patch grid (proxy for patch size, manual S29)
```
                 config  Overall SRCC  Mean(6) SRCC  train s / run  test ms / clip
7x7 = 49 patches (full)        0.9403        0.8795        57.0775          1.3940
                    4x4        0.9399        0.8827        28.9068          0.7084
                    3x3        0.9387        0.8853        19.7202          0.5240
                    2x2        0.9413        0.8855        16.9494          0.3586
```

## number of frames T (manual S30)
```
     config  Overall SRCC  Mean(6) SRCC  train s / run  test ms / clip
T=16 (full)        0.9403        0.8795        57.0775          1.3940
        T=8        0.9206        0.8539        28.2566          0.7861
```

## Attention monitors (collapse check, attribute specificity)
Entropy is normalised to [0,1] (1 = uniform attention, near 0 = collapsed on one patch/frame). beta_attr_diff = mean pairwise half-L1 distance between the five attribute-specific beta curves (0 = identical, 1 = disjoint).
```
                                             spatial_entropy  temporal_entropy  beta_attr_diff
S1T1M1P1 [FINAL = M9 + plain concatenation]           0.9752            0.9927          0.0908
S1T0M0P0                                              0.9632               NaN             NaN
S0T1M0P0                                                 NaN            0.9873          0.1262
A5_T8                                                 0.9770            0.9936          0.0657
A6_grid4                                              0.9783            0.9891          0.1057
A6_grid3                                              0.9659            0.9891          0.1037
A6_grid2                                              0.9377            0.9872          0.1125
```

## Frame-order check (full model, test frames shuffled, not retrained)
Overall SRCC 0.9403 -> 0.9400; Mean(6) SRCC 0.8795 -> 0.8792. A small drop means the model uses little temporal order.

## S1T1M1P1 [FINAL = M9 + plain concatenation] vs DARNet (paper protocol)
```
        SRCC DARNet SRCC ours SRCC gap PLCC DARNet PLCC ours PLCC gap KRCC DARNet KRCC ours KRCC gap RMSE DARNet RMSE ours RMSE gap
Score                                                                                                                              
TSV           0.910     0.904   -0.006       0.924     0.920   -0.004       0.744     0.737   -0.007       0.252     0.259   +0.007
B             0.798     0.783   -0.015       0.821     0.808   -0.013       0.607     0.593   -0.014       0.459     0.477   +0.018
SR            0.841     0.823   -0.018       0.855     0.832   -0.023       0.654     0.630   -0.024       0.343     0.376   +0.033
S             0.928     0.924   -0.004       0.933     0.930   -0.003       0.768     0.762   -0.006       0.276     0.288   +0.012
U             0.906     0.902   -0.004       0.914     0.902   -0.012       0.737     0.730   -0.007       0.283     0.308   +0.025
Overall       0.940     0.940   +0.000       0.943     0.940   -0.003       0.790     0.787   -0.003       0.332     0.350   +0.018
Mean(6)       0.887     0.879   -0.008       0.898     0.889   -0.009       0.717     0.706   -0.011       0.324     0.343   +0.019
```

## A6_grid2 vs DARNet (paper protocol)
```
        SRCC DARNet SRCC ours SRCC gap PLCC DARNet PLCC ours PLCC gap KRCC DARNet KRCC ours KRCC gap RMSE DARNet RMSE ours RMSE gap
Score                                                                                                                              
TSV           0.910     0.908   -0.002       0.924     0.924   +0.000       0.744     0.743   -0.001       0.252     0.253   +0.001
B             0.798     0.791   -0.007       0.821     0.815   -0.006       0.607     0.604   -0.003       0.459     0.469   +0.010
SR            0.841     0.837   -0.004       0.855     0.845   -0.010       0.654     0.646   -0.008       0.343     0.362   +0.019
S             0.928     0.929   +0.001       0.933     0.934   +0.001       0.768     0.770   +0.002       0.276     0.279   +0.003
U             0.906     0.907   +0.001       0.914     0.908   -0.006       0.737     0.737   -0.000       0.283     0.299   +0.016
Overall       0.940     0.941   +0.001       0.943     0.941   -0.002       0.790     0.788   -0.002       0.332     0.346   +0.014
Mean(6)       0.887     0.886   -0.001       0.898     0.895   -0.003       0.717     0.715   -0.002       0.324     0.335   +0.011
```

Best configuration by mean validation Mean(6) SRCC (selected without test labels): A6_grid2 (0.8835). Full model: 0.8753.

## Size and time
```
                                                params  epochs_run  best_epoch  train_s  test_ms_per_clip
S1T1M1P1 [FINAL = M9 + plain concatenation]  4260245.0        19.9         9.9   57.077             1.394
S1T0M0P0                                     3246864.0        18.1         8.1   43.017             1.057
S0T1M0P0                                     3164304.0        16.6         6.6   34.937             0.940
S0T0M1P0                                     3868171.0        20.3        10.3   50.461             1.255
S0T0M0P1                                     3226123.0        16.9         6.9   35.329             0.942
S0T0M0P0                                     3081739.0        17.0         7.0   35.424             0.939
A5_T8                                        4258197.0        17.8         7.8   28.257             0.786
A6_grid4                                     4251797.0        22.4        12.4   28.907             0.708
A6_grid3                                     4250005.0        21.3        11.3   19.720             0.524
A6_grid2                                     4248725.0        24.7        14.7   16.949             0.359
```

## Fixed hyper-parameters (identical for every configuration)
```
D                      256.0000
DROPOUT                  0.2000
HEADS                    4.0000
SP_LAYERS                1.0000
T_LAYERS                 2.0000
LR                       0.0005
WD                       0.0100
WARMUP                   2.0000
GRAD_CLIP                1.0000
LAMBDA_RANK              0.1000
RANK_MARGIN              0.0500
LAMBDA_TEMP              0.5000
TEMP_TAU                 0.1000
epochs_max              40.0000
batch                   32.0000
early_stop_patience     10.0000
```

## Logistic-mapping parameters, full model (mean over seeds)
```
                                     config score  val-fit b1  val-fit b2  val-fit b3  val-fit b4  test-fit b1  test-fit b2  test-fit b3  test-fit b4
S1T1M1P1 [FINAL = M9 + plain concatenation]   TSV      88.429    -434.939      -1.652       4.783      126.236      -36.648       18.811        7.818
S1T1M1P1 [FINAL = M9 + plain concatenation]     B       3.416      -0.261       1.540       0.789        3.713       -0.344        1.654        0.675
S1T1M1P1 [FINAL = M9 + plain concatenation]    SR     134.007      -2.118       7.766       2.763       23.908     -118.350        2.800        5.372
S1T1M1P1 [FINAL = M9 + plain concatenation]     S     121.220    -195.672       0.661       4.997      153.696      -33.774        7.212        7.674
S1T1M1P1 [FINAL = M9 + plain concatenation]     U     999.092    -428.005      -8.470      13.417      325.943     -177.297       17.988        8.145
S1T1M1P1 [FINAL = M9 + plain concatenation]     O      62.625    -293.825      -7.741      12.423      117.658      -57.996       13.131        7.382
```
