# Ablation study 2: the final model (M9 with plain concatenation)
Protocol A (random split, seed s = split s, identical to the main study): **10 seeds** ([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]). PLCC/RMSE use the validation-fitted logistic mapping unless stated. Bold = best in a column. Full model = **S1T1M1P1 [FINAL = M9 + plain concatenation]**.

Factors: **S** = spatial attention (alpha); **T** = temporal attention (beta); **M** = multi-stage features (layer2+3); **P** = photometric descriptors. A cell name lists each factor with 1 = present, 0 = removed (S1T1M1P1 is the FINAL model; every cell keeps plain concatenation fusion).

## Factorial cells (all on/off combinations): Overall and Mean(6), mean ± std
| Configuration | Overall SRCC | Overall PLCC | Overall KRCC | Overall RMSE | Mean(6) SRCC | Mean(6) PLCC | Mean(6) KRCC | Mean(6) RMSE |
|---|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | **0.9403 ± 0.0079** | 0.9391 ± 0.0060 | 0.7874 ± 0.0146 | 0.3567 ± 0.0149 | **0.8795 ± 0.0081** | 0.8853 ± 0.0065 | 0.7065 ± 0.0095 | **0.3522 ± 0.0087** |
| S1T1M0P0 | 0.9310 ± 0.0077 | 0.9314 ± 0.0062 | 0.7717 ± 0.0141 | 0.3798 ± 0.0124 | 0.8730 ± 0.0058 | 0.8789 ± 0.0069 | 0.6994 ± 0.0069 | 0.3607 ± 0.0082 |
| S1T0M1P0 | 0.9401 ± 0.0076 | **0.9399 ± 0.0062** | **0.7880 ± 0.0135** | **0.3550 ± 0.0132** | 0.8728 ± 0.0100 | 0.8796 ± 0.0073 | 0.6999 ± 0.0107 | 0.3588 ± 0.0084 |
| S1T0M0P1 | 0.9357 ± 0.0081 | 0.9348 ± 0.0076 | 0.7792 ± 0.0147 | 0.3694 ± 0.0203 | 0.8789 ± 0.0071 | 0.8847 ± 0.0049 | **0.7066 ± 0.0079** | 0.3528 ± 0.0056 |
| S0T1M1P0 | 0.9380 ± 0.0084 | 0.9381 ± 0.0071 | 0.7845 ± 0.0155 | 0.3605 ± 0.0192 | 0.8713 ± 0.0065 | 0.8792 ± 0.0059 | 0.6983 ± 0.0074 | 0.3595 ± 0.0087 |
| S0T1M0P1 | 0.9352 ± 0.0079 | 0.9344 ± 0.0072 | 0.7776 ± 0.0139 | 0.3711 ± 0.0178 | 0.8795 ± 0.0083 | **0.8855 ± 0.0056** | 0.7063 ± 0.0090 | 0.3529 ± 0.0067 |
| S0T0M1P1 | 0.9380 ± 0.0081 | 0.9376 ± 0.0072 | 0.7836 ± 0.0140 | 0.3621 ± 0.0190 | 0.8786 ± 0.0093 | 0.8840 ± 0.0081 | 0.7054 ± 0.0106 | 0.3538 ± 0.0088 |

## Factorial cells (all on/off combinations): Overall and Mean(6), median
| Configuration | Overall SRCC | Overall PLCC | Overall KRCC | Overall RMSE | Mean(6) SRCC | Mean(6) PLCC | Mean(6) KRCC | Mean(6) RMSE |
|---|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | **0.9420** | 0.9400 | 0.7885 | **0.3572** | 0.8776 | 0.8839 | 0.7038 | 0.3542 |
| S1T1M0P0 | 0.9324 | 0.9336 | 0.7725 | 0.3815 | 0.8743 | 0.8803 | 0.7002 | 0.3608 |
| S1T0M1P0 | 0.9394 | **0.9401** | **0.7889** | 0.3574 | 0.8697 | 0.8768 | 0.6979 | 0.3598 |
| S1T0M0P1 | 0.9362 | 0.9347 | 0.7783 | 0.3720 | 0.8776 | 0.8851 | 0.7036 | **0.3517** |
| S0T1M1P0 | 0.9337 | 0.9360 | 0.7780 | 0.3673 | 0.8711 | 0.8787 | 0.6963 | 0.3587 |
| S0T1M0P1 | 0.9370 | 0.9347 | 0.7777 | 0.3702 | 0.8779 | **0.8858** | 0.7038 | 0.3521 |
| S0T0M1P1 | 0.9385 | 0.9398 | 0.7845 | 0.3636 | **0.8782** | 0.8854 | **0.7045** | 0.3539 |

## Manual ablations and controls (one change each, relative to the full model): Overall and Mean(6), mean ± std
| Configuration | Overall SRCC | Overall PLCC | Overall KRCC | Overall RMSE | Mean(6) SRCC | Mean(6) PLCC | Mean(6) KRCC | Mean(6) RMSE |
|---|---|---|---|---|---|---|---|---|
| A2_spatial_max | **0.9400 ± 0.0084** | **0.9389 ± 0.0072** | **0.7872 ± 0.0152** | **0.3581 ± 0.0173** | **0.8807 ± 0.0069** | **0.8871 ± 0.0049** | **0.7081 ± 0.0090** | **0.3505 ± 0.0072** |
| A3_temporal_max | 0.9352 ± 0.0103 | 0.9357 ± 0.0079 | 0.7795 ± 0.0172 | 0.3669 ± 0.0208 | 0.8677 ± 0.0084 | 0.8755 ± 0.0069 | 0.6918 ± 0.0095 | 0.3641 ± 0.0097 |

## Manual ablations and controls (one change each, relative to the full model): Overall and Mean(6), median
| Configuration | Overall SRCC | Overall PLCC | Overall KRCC | Overall RMSE | Mean(6) SRCC | Mean(6) PLCC | Mean(6) KRCC | Mean(6) RMSE |
|---|---|---|---|---|---|---|---|---|
| A2_spatial_max | **0.9389** | **0.9383** | **0.7856** | 0.3674 | **0.8804** | **0.8871** | **0.7058** | **0.3503** |
| A3_temporal_max | 0.9383 | 0.9367 | 0.7835 | **0.3662** | 0.8706 | 0.8790 | 0.6937 | 0.3619 |

## Per-score SRCC, all configurations, mean
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.9039 | 0.7829 | 0.8230 | 0.9243 | 0.9024 | **0.9403** | 0.8795 |
| S1T1M0P0 | 0.9019 | 0.7675 | 0.8144 | 0.9232 | 0.9003 | 0.9310 | 0.8730 |
| S1T0M1P0 | 0.8986 | 0.7479 | 0.8248 | 0.9238 | 0.9014 | 0.9401 | 0.8728 |
| S1T0M0P1 | **0.9041** | 0.7746 | 0.8269 | **0.9275** | **0.9045** | 0.9357 | 0.8789 |
| S0T1M1P0 | 0.8986 | 0.7501 | 0.8201 | 0.9215 | 0.8995 | 0.9380 | 0.8713 |
| S0T1M0P1 | 0.9031 | 0.7817 | **0.8296** | 0.9255 | 0.9016 | 0.9352 | 0.8795 |
| S0T0M1P1 | 0.9027 | 0.7831 | 0.8220 | 0.9259 | 0.9002 | 0.9380 | 0.8786 |
| A2_spatial_max | 0.9040 | **0.7928** | 0.8220 | 0.9230 | 0.9025 | 0.9400 | **0.8807** |
| A3_temporal_max | 0.8960 | 0.7808 | 0.7840 | 0.9202 | 0.8900 | 0.9352 | 0.8677 |

## Per-score SRCC, all configurations, median
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.9036 | 0.7817 | 0.8214 | 0.9277 | 0.8997 | **0.9420** | 0.8776 |
| S1T1M0P0 | 0.9028 | 0.7658 | 0.8164 | 0.9281 | 0.9009 | 0.9324 | 0.8743 |
| S1T0M1P0 | 0.9008 | 0.7468 | 0.8246 | 0.9289 | 0.8954 | 0.9394 | 0.8697 |
| S1T0M0P1 | **0.9076** | 0.7776 | 0.8257 | **0.9296** | **0.9041** | 0.9362 | 0.8776 |
| S0T1M1P0 | 0.8990 | 0.7515 | 0.8176 | 0.9248 | 0.9014 | 0.9337 | 0.8711 |
| S0T1M0P1 | 0.9054 | 0.7873 | **0.8359** | 0.9249 | 0.8959 | 0.9370 | 0.8779 |
| S0T0M1P1 | 0.9052 | 0.7820 | 0.8246 | 0.9295 | 0.8976 | 0.9385 | 0.8782 |
| A2_spatial_max | 0.9051 | **0.7973** | 0.8250 | 0.9267 | 0.8997 | 0.9389 | **0.8804** |
| A3_temporal_max | 0.8969 | 0.7807 | 0.7777 | 0.9228 | 0.8893 | 0.9383 | 0.8706 |

## Per-score PLCC, all configurations, mean
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.9169 | 0.8014 | 0.8258 | 0.9293 | 0.8995 | 0.9391 | 0.8853 |
| S1T1M0P0 | 0.9160 | 0.7751 | 0.8221 | 0.9296 | 0.8993 | 0.9314 | 0.8789 |
| S1T0M1P0 | 0.9144 | 0.7702 | 0.8255 | 0.9284 | 0.8993 | **0.9399** | 0.8796 |
| S1T0M0P1 | **0.9179** | 0.7890 | 0.8313 | **0.9318** | **0.9034** | 0.9348 | 0.8847 |
| S0T1M1P0 | 0.9135 | 0.7735 | 0.8241 | 0.9274 | 0.8988 | 0.9381 | 0.8792 |
| S0T1M0P1 | 0.9169 | 0.7960 | **0.8325** | 0.9314 | 0.9019 | 0.9344 | 0.8855 |
| S0T0M1P1 | 0.9162 | 0.7989 | 0.8224 | 0.9307 | 0.8983 | 0.9376 | 0.8840 |
| A2_spatial_max | 0.9177 | **0.8120** | 0.8244 | 0.9288 | 0.9007 | 0.9389 | **0.8871** |
| A3_temporal_max | 0.9108 | 0.7993 | 0.7907 | 0.9262 | 0.8901 | 0.9357 | 0.8755 |

## Per-score PLCC, all configurations, median
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.9196 | 0.8032 | 0.8281 | 0.9285 | 0.8971 | 0.9400 | 0.8839 |
| S1T1M0P0 | 0.9160 | 0.7869 | 0.8243 | 0.9278 | 0.9008 | 0.9336 | 0.8803 |
| S1T0M1P0 | 0.9163 | 0.7689 | 0.8277 | 0.9309 | 0.8971 | **0.9401** | 0.8768 |
| S1T0M0P1 | 0.9197 | 0.7912 | 0.8293 | 0.9305 | **0.9013** | 0.9347 | 0.8851 |
| S0T1M1P0 | 0.9165 | 0.7725 | 0.8275 | 0.9285 | 0.8969 | 0.9360 | 0.8787 |
| S0T1M0P1 | 0.9173 | 0.7954 | **0.8392** | **0.9331** | 0.8993 | 0.9347 | 0.8858 |
| S0T0M1P1 | **0.9205** | 0.7980 | 0.8276 | 0.9319 | 0.8991 | 0.9398 | 0.8854 |
| A2_spatial_max | 0.9188 | **0.8147** | 0.8258 | 0.9287 | 0.8996 | 0.9383 | **0.8871** |
| A3_temporal_max | 0.9126 | 0.7983 | 0.7827 | 0.9257 | 0.8905 | 0.9367 | 0.8790 |

## Per-score KRCC, all configurations, mean
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.7370 | 0.5928 | 0.6297 | 0.7619 | 0.7300 | 0.7874 | 0.7065 |
| S1T1M0P0 | 0.7343 | 0.5812 | 0.6230 | 0.7607 | 0.7255 | 0.7717 | 0.6994 |
| S1T0M1P0 | 0.7298 | 0.5603 | 0.6315 | 0.7610 | 0.7287 | **0.7880** | 0.6999 |
| S1T0M0P1 | **0.7384** | 0.5857 | 0.6371 | **0.7670** | **0.7324** | 0.7792 | 0.7066 |
| S0T1M1P0 | 0.7291 | 0.5649 | 0.6261 | 0.7580 | 0.7276 | 0.7845 | 0.6983 |
| S0T1M0P1 | 0.7361 | 0.5943 | **0.6371** | 0.7645 | 0.7279 | 0.7776 | 0.7063 |
| S0T0M1P1 | 0.7349 | 0.5931 | 0.6287 | 0.7648 | 0.7271 | 0.7836 | 0.7054 |
| A2_spatial_max | 0.7382 | **0.6046** | 0.6282 | 0.7599 | 0.7303 | 0.7872 | **0.7081** |
| A3_temporal_max | 0.7243 | 0.5894 | 0.5909 | 0.7553 | 0.7115 | 0.7795 | 0.6918 |

## Per-score KRCC, all configurations, median
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.7344 | 0.5924 | 0.6313 | 0.7678 | 0.7275 | 0.7885 | 0.7038 |
| S1T1M0P0 | 0.7351 | 0.5801 | 0.6253 | 0.7689 | 0.7264 | 0.7725 | 0.7002 |
| S1T0M1P0 | 0.7345 | 0.5610 | 0.6286 | 0.7670 | 0.7222 | **0.7889** | 0.6979 |
| S1T0M0P1 | **0.7426** | 0.5915 | 0.6343 | 0.7687 | **0.7343** | 0.7783 | 0.7036 |
| S0T1M1P0 | 0.7278 | 0.5652 | 0.6256 | 0.7611 | 0.7306 | 0.7780 | 0.6963 |
| S0T1M0P1 | 0.7407 | 0.6019 | **0.6436** | 0.7647 | 0.7225 | 0.7777 | 0.7038 |
| S0T0M1P1 | 0.7353 | 0.5931 | 0.6283 | **0.7720** | 0.7256 | 0.7845 | 0.7045 |
| A2_spatial_max | 0.7389 | **0.6123** | 0.6304 | 0.7639 | 0.7268 | 0.7856 | **0.7058** |
| A3_temporal_max | 0.7253 | 0.5880 | 0.5815 | 0.7600 | 0.7078 | 0.7835 | 0.6937 |

## Per-score RMSE, all configurations, mean
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.2672 | 0.4905 | 0.3893 | 0.2926 | 0.3171 | 0.3567 | 0.3522 |
| S1T1M0P0 | 0.2685 | 0.5145 | 0.3916 | 0.2923 | 0.3172 | **0.3798** | 0.3607 |
| S1T0M1P0 | 0.2712 | **0.5230** | 0.3905 | 0.2952 | 0.3179 | 0.3550 | 0.3588 |
| S1T0M0P1 | 0.2652 | 0.5016 | 0.3809 | 0.2887 | 0.3109 | 0.3694 | 0.3528 |
| S0T1M1P0 | 0.2720 | 0.5182 | 0.3911 | 0.2967 | 0.3186 | 0.3605 | 0.3595 |
| S0T1M0P1 | 0.2671 | 0.4960 | 0.3795 | 0.2898 | 0.3137 | 0.3711 | 0.3529 |
| S0T0M1P1 | 0.2691 | 0.4919 | 0.3918 | 0.2901 | 0.3178 | 0.3621 | 0.3538 |
| A2_spatial_max | 0.2660 | 0.4778 | 0.3915 | 0.2948 | 0.3145 | 0.3581 | 0.3505 |
| A3_temporal_max | **0.2765** | 0.4933 | **0.4187** | **0.2996** | **0.3294** | 0.3669 | **0.3641** |

## Per-score RMSE, all configurations, median
| Configuration | TSV | B | SR | S | U | Overall | Mean(6) |
|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | 0.2641 | 0.4895 | 0.3872 | 0.2921 | 0.3226 | 0.3572 | 0.3542 |
| S1T1M0P0 | 0.2697 | 0.5097 | 0.3901 | 0.2926 | 0.3205 | **0.3815** | 0.3608 |
| S1T0M1P0 | 0.2693 | **0.5162** | 0.3831 | 0.2910 | 0.3208 | 0.3574 | 0.3598 |
| S1T0M0P1 | 0.2653 | 0.5043 | 0.3823 | 0.2831 | 0.3139 | 0.3720 | 0.3517 |
| S0T1M1P0 | 0.2707 | 0.5152 | 0.3908 | 0.2918 | 0.3219 | 0.3673 | 0.3587 |
| S0T1M0P1 | 0.2690 | 0.5025 | 0.3812 | 0.2844 | 0.3145 | 0.3702 | 0.3521 |
| S0T0M1P1 | 0.2656 | 0.4912 | 0.3889 | 0.2863 | 0.3216 | 0.3636 | 0.3539 |
| A2_spatial_max | 0.2680 | 0.4726 | 0.3839 | 0.2944 | 0.3214 | 0.3674 | 0.3503 |
| A3_temporal_max | **0.2744** | 0.4976 | **0.4174** | **0.2948** | **0.3278** | 0.3662 | **0.3619** |

## Same with the mapping fitted on the test predictions (paper protocol), mean
| Configuration | Overall SRCC | Overall PLCC | Overall KRCC | Overall RMSE | Mean(6) SRCC | Mean(6) PLCC | Mean(6) KRCC | Mean(6) RMSE |
|---|---|---|---|---|---|---|---|---|
| S1T1M1P1 [FINAL = M9 + plain concatenation] | **0.9403** | 0.9399 | 0.7874 | 0.3502 | 0.8795 | 0.8886 | 0.7065 | 0.3431 |
| S1T1M0P0 | 0.9310 | 0.9320 | 0.7717 | 0.3715 | 0.8730 | 0.8834 | 0.6994 | 0.3510 |
| S1T0M1P0 | 0.9401 | **0.9406** | **0.7880** | **0.3481** | 0.8728 | 0.8828 | 0.6999 | 0.3493 |
| S1T0M0P1 | 0.9357 | 0.9357 | 0.7792 | 0.3617 | 0.8789 | 0.8885 | 0.7066 | 0.3439 |
| S0T1M1P0 | 0.9380 | 0.9392 | 0.7845 | 0.3521 | 0.8713 | 0.8819 | 0.6983 | 0.3512 |
| S0T1M0P1 | 0.9352 | 0.9354 | 0.7776 | 0.3625 | 0.8795 | 0.8893 | 0.7063 | 0.3434 |
| S0T0M1P1 | 0.9380 | 0.9382 | 0.7836 | 0.3546 | 0.8786 | 0.8879 | 0.7054 | 0.3442 |
| A2_spatial_max | 0.9400 | 0.9397 | 0.7872 | 0.3503 | **0.8807** | **0.8896** | **0.7081** | **0.3421** |
| A3_temporal_max | 0.9352 | 0.9362 | 0.7795 | 0.3602 | 0.8677 | 0.8784 | 0.6918 | 0.3560 |

## Every configuration vs the full model (paired on the same splits; Holm correction within each metric)
```
         config     group                 metric  mean_diff_vs_full  median_diff  seeds_worse_than_full  n  p_wilcoxon  p_holm_within_metric
       S1T1M0P0 factorial           Overall SRCC            -0.0093      -0.0083                     10 10      0.0020                0.0156
       S1T1M0P0 factorial           Mean(6) SRCC            -0.0065      -0.0038                      9 10      0.0371                0.1855
       S1T1M0P0 factorial Overall PLCC (val-fit)            -0.0077      -0.0065                     10 10      0.0020                0.0156
       S1T1M0P0 factorial Overall RMSE (val-fit)             0.0231       0.0200                     10 10      0.0020                0.0156
       S1T0M1P0 factorial           Overall SRCC            -0.0002       0.0001                      5 10      0.9219                1.0000
       S1T0M1P0 factorial           Mean(6) SRCC            -0.0067      -0.0081                      9 10      0.0195                0.1172
       S1T0M1P0 factorial Overall PLCC (val-fit)             0.0009       0.0011                      3 10      0.6250                1.0000
       S1T0M1P0 factorial Overall RMSE (val-fit)            -0.0018      -0.0021                      4 10      0.5566                1.0000
       S1T0M0P1 factorial           Overall SRCC            -0.0046      -0.0049                      9 10      0.0098                0.0684
       S1T0M0P1 factorial           Mean(6) SRCC            -0.0006      -0.0012                      6 10      0.7695                1.0000
       S1T0M0P1 factorial Overall PLCC (val-fit)            -0.0043      -0.0050                      9 10      0.0039                0.0234
       S1T0M0P1 factorial Overall RMSE (val-fit)             0.0127       0.0134                      9 10      0.0039                0.0234
       S0T1M1P0 factorial           Overall SRCC            -0.0023      -0.0006                      5 10      0.3750                1.0000
       S0T1M1P0 factorial           Mean(6) SRCC            -0.0082      -0.0081                      9 10      0.0039                0.0273
       S0T1M1P0 factorial Overall PLCC (val-fit)            -0.0010       0.0006                      4 10      0.8457                1.0000
       S0T1M1P0 factorial Overall RMSE (val-fit)             0.0038       0.0022                      5 10      0.5566                1.0000
       S0T1M0P1 factorial           Overall SRCC            -0.0051      -0.0024                      8 10      0.0098                0.0684
       S0T1M0P1 factorial           Mean(6) SRCC            -0.0000       0.0003                      5 10      0.9219                1.0000
       S0T1M0P1 factorial Overall PLCC (val-fit)            -0.0046      -0.0019                     10 10      0.0020                0.0156
       S0T1M0P1 factorial Overall RMSE (val-fit)             0.0144       0.0077                     10 10      0.0020                0.0156
       S0T0M1P1 factorial           Overall SRCC            -0.0023      -0.0020                      7 10      0.1934                0.7734
       S0T0M1P1 factorial           Mean(6) SRCC            -0.0008       0.0002                      4 10      0.9219                1.0000
       S0T0M1P1 factorial Overall PLCC (val-fit)            -0.0014      -0.0007                      6 10      0.5566                1.0000
       S0T0M1P1 factorial Overall RMSE (val-fit)             0.0053       0.0027                      6 10      0.3750                1.0000
 A2_spatial_max     extra           Overall SRCC            -0.0003      -0.0006                      5 10      0.7695                1.0000
 A2_spatial_max     extra           Mean(6) SRCC             0.0012       0.0006                      4 10      0.3223                1.0000
 A2_spatial_max     extra Overall PLCC (val-fit)            -0.0002      -0.0008                      5 10      0.9219                1.0000
 A2_spatial_max     extra Overall RMSE (val-fit)             0.0014       0.0034                      6 10      0.5566                1.0000
A3_temporal_max     extra           Overall SRCC            -0.0052      -0.0051                      9 10      0.0098                0.0684
A3_temporal_max     extra           Mean(6) SRCC            -0.0118      -0.0129                     10 10      0.0020                0.0156
A3_temporal_max     extra Overall PLCC (val-fit)            -0.0033      -0.0029                      7 10      0.0488                0.2441
A3_temporal_max     extra Overall RMSE (val-fit)             0.0101       0.0086                      8 10      0.0371                0.1855
```

## Mean SRCC change vs the full model, per score
```
                    TSV       B      SR       S       U  Overall  Mean(6)
S1T1M0P0        -0.0020 -0.0154 -0.0087 -0.0011 -0.0021  -0.0093  -0.0065
S1T0M1P0        -0.0053 -0.0350  0.0018 -0.0005 -0.0010  -0.0002  -0.0067
S1T0M0P1         0.0002 -0.0083  0.0039  0.0032  0.0022  -0.0046  -0.0006
S0T1M1P0        -0.0053 -0.0328 -0.0029 -0.0029 -0.0029  -0.0023  -0.0082
S0T1M0P1        -0.0008 -0.0012  0.0065  0.0012 -0.0008  -0.0051  -0.0000
S0T0M1P1        -0.0012  0.0002 -0.0010  0.0015 -0.0022  -0.0023  -0.0008
A2_spatial_max   0.0001  0.0099 -0.0010 -0.0014  0.0001  -0.0003   0.0012
A3_temporal_max -0.0079 -0.0021 -0.0391 -0.0042 -0.0124  -0.0052  -0.0118
```

## Attention monitors (collapse check, attribute specificity)
Entropy is normalised to [0,1] (1 = uniform attention, near 0 = collapsed on one patch/frame). beta_attr_diff = mean pairwise half-L1 distance between the five attribute-specific beta curves (0 = identical, 1 = disjoint).
```
                                             spatial_entropy  temporal_entropy  beta_attr_diff
S1T1M1P1 [FINAL = M9 + plain concatenation]           0.9752            0.9927          0.0908
S1T1M0P0                                              0.9680            0.9899          0.1197
S1T0M1P0                                              0.9749               NaN             NaN
S1T0M0P1                                              0.9802               NaN             NaN
S0T1M1P0                                                 NaN            0.9957          0.0726
S0T1M0P1                                                 NaN            0.9849          0.1400
A2_spatial_max                                           NaN            0.9931          0.0883
A3_temporal_max                                       0.9801               NaN             NaN
```

## Frame-order check (full model, test frames shuffled, not retrained)
Overall SRCC 0.9403 -> 0.9400; Mean(6) SRCC 0.8795 -> 0.8792. A small drop means the model uses little temporal order.

## S1T1M1P1 [FINAL = M9 + plain concatenation] vs DARNet (paper protocol)
```
        SRCC DARNet SRCC ours SRCC gap PLCC DARNet PLCC ours PLCC gap KRCC DARNet KRCC ours KRCC gap RMSE DARNet RMSE ours RMSE gap
Score                                                                                                                              
TSV           0.910     0.904   -0.006       0.924     0.920   -0.004       0.744     0.737   -0.007       0.252     0.259   +0.007
B             0.798     0.783   -0.015       0.821     0.808   -0.013       0.607     0.593   -0.014       0.459     0.477   +0.018
SR            0.841     0.823   -0.018       0.855     0.832   -0.023       0.654     0.630   -0.024       0.343     0.376   +0.033
S             0.928     0.924   -0.004       0.933     0.930   -0.003       0.768     0.762   -0.006       0.276     0.288   +0.012
U             0.906     0.902   -0.004       0.914     0.902   -0.012       0.737     0.730   -0.007       0.283     0.308   +0.025
Overall       0.940     0.940   +0.000       0.943     0.940   -0.003       0.790     0.787   -0.003       0.332     0.350   +0.018
Mean(6)       0.887     0.879   -0.008       0.898     0.889   -0.009       0.717     0.706   -0.011       0.324     0.343   +0.019
```

## A2_spatial_max vs DARNet (paper protocol)
```
        SRCC DARNet SRCC ours SRCC gap PLCC DARNet PLCC ours PLCC gap KRCC DARNet KRCC ours KRCC gap RMSE DARNet RMSE ours RMSE gap
Score                                                                                                                              
TSV           0.910     0.904   -0.006       0.924     0.921   -0.003       0.744     0.738   -0.006       0.252     0.259   +0.007
B             0.798     0.793   -0.005       0.821     0.816   -0.005       0.607     0.605   -0.002       0.459     0.469   +0.010
SR            0.841     0.822   -0.019       0.855     0.830   -0.025       0.654     0.628   -0.026       0.343     0.379   +0.036
S             0.928     0.923   -0.005       0.933     0.930   -0.003       0.768     0.760   -0.008       0.276     0.288   +0.012
U             0.906     0.902   -0.004       0.914     0.902   -0.012       0.737     0.730   -0.007       0.283     0.308   +0.025
Overall       0.940     0.940   +0.000       0.943     0.940   -0.003       0.790     0.787   -0.003       0.332     0.350   +0.018
Mean(6)       0.887     0.881   -0.006       0.898     0.890   -0.008       0.717     0.708   -0.009       0.324     0.342   +0.018
```

Best configuration by mean validation Mean(6) SRCC (selected without test labels): A2_spatial_max (0.8775). Full model: 0.8753.

## Size and time
```
                                                params  epochs_run  best_epoch  train_s  test_ms_per_clip
S1T1M1P1 [FINAL = M9 + plain concatenation]  4260245.0        19.9         9.9   55.662             1.308
S1T1M0P0                                     3329429.0        17.3         7.3   41.119             0.996
S1T0M1P0                                     4033296.0        19.5         9.5   53.321             1.303
S1T0M0P1                                     3391248.0        16.8         6.8   39.940             0.992
S0T1M1P0                                     3950736.0        23.6        13.6   57.586             1.191
S0T1M0P1                                     3308688.0        17.2         7.2   35.565             0.884
S0T0M1P1                                     4012555.0        17.2         7.2   41.693             1.193
A2_spatial_max                               4095120.0        19.3         9.3   46.309             1.199
A3_temporal_max                              4177680.0        18.4         8.4   50.643             1.310
```

## Fixed hyper-parameters (identical for every configuration)
```
D                      256.0000
DROPOUT                  0.2000
HEADS                    4.0000
SP_LAYERS                1.0000
T_LAYERS                 2.0000
LR                       0.0005
WD                       0.0100
WARMUP                   2.0000
GRAD_CLIP                1.0000
LAMBDA_RANK              0.1000
RANK_MARGIN              0.0500
LAMBDA_TEMP              0.5000
TEMP_TAU                 0.1000
epochs_max              40.0000
batch                   32.0000
early_stop_patience     10.0000
```

## Logistic-mapping parameters, full model (mean over seeds)
```
                                     config score  val-fit b1  val-fit b2  val-fit b3  val-fit b4  test-fit b1  test-fit b2  test-fit b3  test-fit b4
S1T1M1P1 [FINAL = M9 + plain concatenation]   TSV      88.429    -434.939      -1.652       4.783      126.236      -36.648       18.811        7.818
S1T1M1P1 [FINAL = M9 + plain concatenation]     B       3.416      -0.261       1.540       0.789        3.713       -0.344        1.654        0.675
S1T1M1P1 [FINAL = M9 + plain concatenation]    SR     134.007      -2.118       7.766       2.763       23.908     -118.350        2.800        5.372
S1T1M1P1 [FINAL = M9 + plain concatenation]     S     121.220    -195.672       0.661       4.997      153.696      -33.774        7.212        7.674
S1T1M1P1 [FINAL = M9 + plain concatenation]     U     999.092    -428.005      -8.470      13.417      325.943     -177.297       17.988        8.145
S1T1M1P1 [FINAL = M9 + plain concatenation]     O      62.625    -293.825      -7.741      12.423      117.658      -57.996       13.131        7.382
```
